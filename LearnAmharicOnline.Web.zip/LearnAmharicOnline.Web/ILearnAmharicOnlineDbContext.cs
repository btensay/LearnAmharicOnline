﻿namespace LearnAmharicOnline.Web
{
    public interface ILearnAmharicOnlineDbContext
    {
    }
}
