﻿using AutoMapper;
using System.Web.Mvc;

namespace LearnAmharicOnline.Web.Controllers
{
    public abstract partial class BaseController : Controller
    {
        private IMapper _mapper = null;

        protected IMapper Mapper
        {
            get
            {
                if (_mapper == null)
                {
                    _mapper = new Mapper(MvcApplication.MapperConfiguration);
                }

                return _mapper;
            }
        }
    }
}
