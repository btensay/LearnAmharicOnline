﻿using System.Linq;
using System.Web.Mvc;
using LearnAmharicOnline.Web.Models;
using LearnAmharicOnline.Services;
using LearnAmharicOnline.Services.AmharicCoursePackages;
using System.Collections.Generic;
using LearnAmharicOnline.Core;
using LearnAmharicOnline.Services.Customers;
using System;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using WebMatrix.WebData;
using LearnAmharicOnline.Web.Filters;
using LearnAmharicOnline.Core.Membership;
using LearnAmharicOnline.Services.Subscriptions;

namespace LearnAmharicOnline.Web.Controllers
{
    [InitializeSimpleMembership]
    public class HomeController : BaseController
    {
        private IAmharicServiceProvider _amharicServiceProvider;
        private IAmharicCoursePackageService _amharicCoursePackageService;
        private ICustomerService _customerServiceService;
        private ICourseSubscriptionsService _courseSubscriptionsService;

        public HomeController(IAmharicServiceProvider amharicServiceProvider)
        {
            _amharicServiceProvider = amharicServiceProvider;
            _amharicCoursePackageService = _amharicServiceProvider.AmharicCoursePackageService;
            _customerServiceService = _amharicServiceProvider.CustomerService;
            _courseSubscriptionsService = _amharicServiceProvider.CourseSubscriptionsService;
        }

        [HttpGet]
        public ActionResult Index()
        {
            ViewBag.Message = "Learn Amharic Online - Homepage.";
            var viewModel = new CustomerViewModel();

            var currentUserId = WebSecurity.GetUserId(User.Identity.Name);

            viewModel.CurrentCustomer = _customerServiceService.GetCustomerById(currentUserId);

            var coursePackages = _courseSubscriptionsService.GetAllCourseSubscriptions();

            if(viewModel.CurrentCustomer != null && viewModel.CurrentCustomer.CourseSubscriptions != null)
            {
                var currentSubscription = viewModel.CurrentCustomer
                                                   .CourseSubscriptions
                                                   .Where(s=>s.SubscriptionStatus == Core.Domain.SubscriptionStatus.Current)
                                                   .FirstOrDefault();

                viewModel.CandidateAmharicCoursePackages = GetListItems(coursePackages, currentSubscription);
            }

            return View(viewModel);
        }

        [Authorize]
        [HttpPost]
        public ActionResult Index(CustomerViewModel viewModel)
        {
            if(ModelState.IsValid)
            {
                var customer = _customerServiceService.GetCustomerById(viewModel.CurrentCustomer.Id);

                if(customer != null)
                {
                    //get selected package to subscribe
                    var packagesSelected = GetSelectedItems(viewModel.CandidateAmharicCoursePackages, new AmharicCoursePackage());

                    var newSubscription = new Core.Membership.CourseSubscription()
                                              {
                                                GlobalId = Guid.NewGuid(),
                                                Description = "new subscription description",
                                                Name = "new subscription name",
                                                StartDate = DateTime.Now,
                                                EndDate = DateTime.Now.AddYears(1), IsRenewed = false,
                                                SubscriptionStatus = Core.Domain.SubscriptionStatus.Current
                                              };

                        packagesSelected.ToList().ForEach(p=> newSubscription.AmharicCoursePackages.Add(p));

                    var previousCurrentSubscription = customer.CourseSubscriptions.Where(s=>s.SubscriptionStatus == Core.Domain.SubscriptionStatus.Current).FirstOrDefault();

                    if(previousCurrentSubscription != null)
                    {
                        previousCurrentSubscription.SubscriptionStatus = Core.Domain.SubscriptionStatus.Expired;
                    }

                    customer.CourseSubscriptions.Add(newSubscription);
                    _customerServiceService.UpdateCustomer(customer);
                }
                return RedirectToAction("Index");
            }

            return View(viewModel);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Learn Amharic Online - About page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Learn Amharic Online - Contact page.";

            return View();
        }

        private IList<SelectListItem> GetListItems<T>(IList<T> listToTransform, CourseSubscription currentCourseSubscription) where T : BaseEntity
        {
            var listToConvertToListItem = listToTransform;

            var list = new List<SelectListItem>();

            if(currentCourseSubscription != null)
            {
                //var currentPackagesIdList = (from package in currentCourseSubscription.AmharicCoursePackages select package.Id).ToList();
                listToConvertToListItem.Where(s => s.Id != currentCourseSubscription.Id)
                       .ToList()
                       .ForEach(i => list.Add(new SelectListItem()
                       {
                           Text = i.Name,
                           Value = i.Id.ToString()
                       }));
            }
            else
            {
                listToConvertToListItem.ToList()
                       .ForEach(i => list.Add(new SelectListItem()
                       {
                           Text = i.Name,
                           Value = i.Id.ToString()
                       }));
            }

            return list;
        }

        private IList<T> GetSelectedItems<T>(IList<SelectListItem> list, T typeToGet) where T : BaseEntity
        {
            var selectedPackagesList = list.Where(i => i.Selected == true).ToList();

            IList<int> wordIdsList = new List<int>();

            selectedPackagesList.ForEach(i => wordIdsList.Add(Convert.ToInt32(i.Value)));

            var packagesList = _amharicCoursePackageService.GetAllAmharicCoursePackages()
                                                           .OfType<T>()
                                                           .Where(s => wordIdsList.Contains(s.Id))
                                                           .ToList();
            return packagesList;
        }
    }
}
