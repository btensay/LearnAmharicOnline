﻿using System.Web.Mvc;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Mvc;
using LearnAmharicOnline.Services;
using LearnAmharicOnline.Services.AmharicCoursePackages;
using LearnAmharicOnline.Services.Subscriptions;
using LearnAmharicOnline.Services.Customers;
using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Data;

namespace LearnAmharicOnline.Web
{
    public class DependencyInjectionBootstrapper
    {
        public static IUnityContainer Initialise()
        {
            var container = BuildUnityContainer();

            DependencyResolver.SetResolver(new UnityDependencyResolver(container));

            return container;
        }

        private static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();

            //register all your components with the container here
            container.RegisterType<IAmharicServiceProvider, AmharicServiceProvider>();
            container.RegisterType<IAmharicCoursePackageService, AmharicCoursePackageService>();
            container.RegisterType<ICourseSubscriptionsService, CourseSubscriptionsService>();

            RegisterTypes(container);

            return container;
        }

        public static void RegisterTypes(IUnityContainer container)
        {
          container.RegisterType<IAmharicServiceProvider, AmharicServiceProvider>();
          container.RegisterType<IAmharicCoursePackageService, AmharicCoursePackageService>();
          container.RegisterType<ICourseSubscriptionsService, CourseSubscriptionsService>();
          container.RegisterType<ICustomerService, CustomerService>();

          container.RegisterType<IUnitOfWork, UnitOfWork>();
         // container.RegisterType<DbContext, LearnAmharicOnlineDbContext>();
          container.RegisterType(typeof(IRepository<>), typeof(LAORepository<>));
        }
    }
}