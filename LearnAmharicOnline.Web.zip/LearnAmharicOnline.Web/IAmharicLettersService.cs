﻿namespace LearnAmharicOnline.Web
{
    internal interface IAmharicLettersService
    {
    }
}