﻿using AutoMapper;
using LearnAmharicOnline.Core.Membership;
using LearnAmharicOnline.Web.Models;

namespace LearnAmharicOnline.Web
{
    public static class AutoMapperWebConfiguration
    {
        public static MapperConfiguration MapperConfiguration()
        {
            return new MapperConfiguration(configurationExpression =>
            {
                configurationExpression.AddProfile(new EditCustomerPost());

            });
        }
    }


    public class EditCustomerPost : Profile
    {
        public EditCustomerPost()
        {
            CreateMap<EditCustomersViewModel, Customer>();
        }
    }


  /*
    public class EditAmharicWordGet : Profile
    {
        public EditAmharicWordGet()
        {
            CreateMap<AmharicWord, AddEditAmharicWordViewModel>()
                .ForMember(vm=>vm.RelatedLetters, opt=>opt.MapFrom(word=>word.RelatedLetters))
                .ForMember(vm => vm.MemoryGameLetterSets, opt => opt.MapFrom(word => word.MemoryGameLetterSets));
        }
    }

    public class EditAmharicWordPost : Profile
    {
        public EditAmharicWordPost()
        {
            CreateMap<AddEditAmharicWordViewModel, AmharicWord>();
        }
    }

    public class EditLetterLearningModuleGet : Profile
    {
        public EditLetterLearningModuleGet()
        {
            CreateMap<LetterLearningModule, EditLetterLearningModuleViewModel>()
                 .ForMember(vm => vm.AmharicLetters, opt => opt.MapFrom(module => module.AmharicLetters));
        }
    }

    public class EditLetterLearningModulePost : Profile
    {
        public EditLetterLearningModulePost()
        {
            CreateMap<EditLetterLearningModuleViewModel, LetterLearningModule>()
                 .ForMember(module => module.AmharicLetters, opt => opt.MapFrom(vm => vm.AmharicLetters));
        }
    }

    public class AddLetterFlashcardsPost : Profile
    {
        public AddLetterFlashcardsPost()
        {
            CreateMap<AddLetterFlashcardsViewModel, AmharicLetterFlashcard>()
                 .ForMember(module => module.FlashCardLetters, opt => opt.MapFrom(vm => vm.FlashCardLetters));
        }
    }

    */
}