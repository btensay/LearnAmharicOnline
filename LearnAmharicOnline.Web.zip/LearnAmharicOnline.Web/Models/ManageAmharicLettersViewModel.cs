﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Membership;
using System.Collections.Generic;
using System.Web.Mvc;

namespace LearnAmharicOnline.Web.Models
{
    public class CustomerViewModel
    {
        public CustomerViewModel()
        {
            CandidateAmharicCoursePackages = new List<SelectListItem>();
        }

        public Customer CurrentCustomer { get; set; }
        public IList<SelectListItem> CandidateAmharicCoursePackages { get; set; }
    }
}