﻿using LearnAmharicOnline.Core.Membership;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LearnAmharicOnline.Web.Models
{
    public class EditCustomersViewModel
    {
        private CourseSubscription _currentCourseSubscription;

        public EditCustomersViewModel()
        {
            _currentCourseSubscription = new CourseSubscription();

            if (CurrentCustomer != null && CurrentCustomer.CourseSubscriptions != null)
            {
                _currentCourseSubscription = CurrentCustomer.CourseSubscriptions
                                                           .Where(s => s.SubscriptionStatus == Core.Domain.SubscriptionStatus.Current)
                                                           .FirstOrDefault();
            }

            CandidateCourseSubscriptions = new List<SelectListItem>();
        }

        public Customer CurrentCustomer { get; set; }
        public CourseSubscription CurrentCourseSubscription { get { return _currentCourseSubscription; } }
        public IList<SelectListItem> CandidateCourseSubscriptions { get; set; }
    }
}