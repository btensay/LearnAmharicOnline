﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Membership;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using LearnAmharicOnline.Core.Domain.Core.Models;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using LearnAmharicOnline.Core;
using LearnAmharicOnline.Core.Domain.Assessment;
using LearnAmharicOnline.Core.Domain.Practice;
using LearnAmharicOnline.Core.Domain.Core;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Words;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.ShortStories;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Grammar;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Proverb;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Expressions;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice;

namespace LearnAmharicOnline.Data
{
    public class LearnAmharicOnlineDbContext: DbContext
    {
        public LearnAmharicOnlineDbContext() : base("LearnAmharicOnlineDbContext") {}

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Entity<User>().ToTable("User")
                        .HasKey(u => u.Id)
                        .Map<Customer>(m => m.Requires("Discriminator").HasValue("Customer"))
                        .Map<LearnAmharicAdmin>(m => m.Requires("Discriminator").HasValue("LearnAmharicAdmin"));

        modelBuilder.Entity<CustomerAddress>().ToTable("CustomerAddress").HasKey(a => a.Id);

        modelBuilder.Entity<CourseSubscription>().ToTable("CourseSubscription").HasKey(s => s.Id);

            modelBuilder.Entity<AmharicLetter>().ToTable("AmharicLetter")
                        .HasKey(l => l.Id)
                        .HasMany<AmharicWord>(l => l.ExampleWords)
                        .WithMany(w => w.RelatedLetters)
                        .Map(cs =>
                        {
                            cs.MapLeftKey("AmharicLetterRefId");
                            cs.MapRightKey("AmharicWordRefId");
                            cs.ToTable("AmharicLetterAmharicWord");
                        });

            modelBuilder.Entity<AmharicLetter>()
                        .HasMany<LetterLearningModule>(w => w.LetterLearningModules)
                        .WithMany(l => l.AmharicLetters)
                        .Map(cs =>
                        {
                            cs.MapLeftKey("AmharicLetterRefId");
                            cs.MapRightKey("LetterLearningModuleRefId");
                            cs.ToTable("AmharicLetterLetterLearningModule");
                        });

            modelBuilder.Entity<AmharicLetter>()
                        .HasMany<MemoryGameLetterSet>(l => l.MemoryGameLetterSets)
                        .WithMany(l => l.AmharicLetters)
                        .Map(cs =>
                        {
                            cs.MapLeftKey("AmharicLetterGameLetterSetRefId");
                            cs.MapRightKey("MemoryGameLetterSetRefId");
                            cs.ToTable("AmharicLetterMemoryGameLetterSet");
                        });

            modelBuilder.Entity<AmharicWord>().ToTable("AmharicWord")
                        .HasKey(w => w.Id)
                        .HasMany<MemoryGameLetterSet>(w => w.MemoryGameLetterSets)
                        .WithMany(s => s.AmharicWords)
                        .Map(cs =>
                        {
                            cs.MapLeftKey("AmharicWordRefId");
                            cs.MapRightKey("AmharicMemoryGameLetterSetRefId");
                            cs.ToTable("AmharicWordAmharicMemoryGameLetterSet");
                        });

            modelBuilder.Entity<AmharicNumeral>().ToTable("AmharicNumeral").HasKey(l => l.Id);

            modelBuilder.Entity<AmharicShortStory>().ToTable("AmharicShortStory").HasKey(l => l.Id);

            modelBuilder.Entity<AmharicWordImage>().ToTable("AmharicWordImage").HasKey(i => i.Id);

            modelBuilder.Entity<AmharicCourseModule>().ToTable("AmharicCourseModule").HasKey(m => m.Id);

            modelBuilder.Entity<AmharicCoursePackage>().ToTable("AmharicCoursePackage").HasKey(m => m.Id);

            modelBuilder.Entity<ExamModule>().ToTable("ExamModule").HasKey(e => e.Id);
            modelBuilder.Entity<AmharicSkillsExam>().ToTable("AmharicSkillsExam").HasKey(e => e.Id);

            modelBuilder.Entity<ExamSection>().ToTable("ExamSection").HasKey(es => es.Id);
            modelBuilder.Entity<ExamQuestion>().ToTable("ExamQuestion").HasKey(eq => eq.Id);

            modelBuilder.Entity<LearningModule>().ToTable("LearningModule").HasKey(m => m.Id);
            modelBuilder.Entity<LetterLearningModule>().ToTable("LetterLearningModule").HasKey(m => m.Id);
            modelBuilder.Entity<WordLearningModule>().ToTable("WordLearningModule").HasKey(m => m.Id);
            modelBuilder.Entity<ShortStoryLearningModule>().ToTable("ShortStoryLearningModule").HasKey(m => m.Id);
            modelBuilder.Entity<GrammarLearningModule>().ToTable("GrammarLearningModule").HasKey(m => m.Id);
            modelBuilder.Entity<ProverbLearningModule>().ToTable("ProverbLearningModule").HasKey(m => m.Id);
            modelBuilder.Entity<ExpressionLearningModule>().ToTable("ExpressionLearningModule").HasKey(m => m.Id);

            modelBuilder.Entity<LearningWrittingResource>().ToTable("LearningWrittingResource").HasKey(wr => wr.Id);
            modelBuilder.Entity<AmharicLetterWritingGuid>().ToTable("AmharicLetterWritingGuid").HasKey(g => g.Id);
            modelBuilder.Entity<LearningReadingResource>().ToTable("LearningReadingResource").HasKey(rr => rr.Id);

            modelBuilder.Entity<AmharicSkillsResult>().ToTable("AmharicSkillsResult").HasKey(wr => wr.Id);

            modelBuilder.Entity<PracticeModule>().ToTable("PracticeModule").HasKey(f => f.Id);
            modelBuilder.Entity<PracticeFlashcard>().ToTable("PracticeFlashcard").HasKey(f => f.Id);
            modelBuilder.Entity<FlashCardLetter>().ToTable("FlashCardLetter").HasKey(f => f.Id);
            modelBuilder.Entity<AmharicLetterFlashcard>().ToTable("AmharicLetterFlashcard").HasKey(m => m.Id);
            modelBuilder.Entity<AmharicWordFlashCard>().ToTable("AmharicWordFlashCard").HasKey(m => m.Id);

            modelBuilder.Entity<PracticeMemoryGame>().ToTable("PracticeMemoryGame").HasKey(f => f.Id);
            modelBuilder.Entity<AmharicLetterMemoryGame>().ToTable("AmharicLetterMemoryGame").HasKey(m => m.Id);
            modelBuilder.Entity<AmharicWordMemoryGame>().ToTable("AmharicWordMemoryGame").HasKey(m => m.Id);

            modelBuilder.Entity<NewsletterSubscription>().ToTable("NewsletterSubscription").HasKey(s => s.Id);
        }

        #region IDbContext interface methods implementations
        /// <summary>
        /// Get DbSet
        /// </summary>
        /// <typeparam name="TEntity">Entity type</typeparam>
        /// <returns>DbSet</returns>
        public new IDbSet<TEntity> Set<TEntity>() where TEntity : BaseEntity
        {
            return base.Set<TEntity>();
        }

        public new int SaveChanges()
        {
            return base.SaveChanges();
        }
        #endregion


        public DbSet<User> Users { get; set; }
        public DbSet<CustomerAddress> Addresses { get; set; }

        public DbSet<AmharicLetter> AmharicLetters { get; set; }
        public DbSet<AmharicNumeral> AmharicNumerals { get; set; }
        public DbSet<AmharicWord> AmharicWords { get; set; }
        public DbSet<AmharicShortStory> AmharicShortStories { get; set; }

        public DbSet<AmharicCourseModule> AmharicCourseModules { get; set; }

        public DbSet<LearningModule> LearningModules { get; set; }
        public DbSet<LetterLearningModule> LetterLearningModules { get; set; }
        public DbSet<WordLearningModule> WordLearningModules { get; set; }
        public DbSet<ShortStoryLearningModule> ShortStoryLearningModules { get; set; }
        public DbSet<GrammarLearningModule> GrammarLearningModules { get; set; }
        public DbSet<ProverbLearningModule> ProverbLearningModules { get; set; }
        public DbSet<ExpressionLearningModule> ExpressionLearningModules { get; set; }

        public DbSet<PracticeModule> PracticeModules { get; set; }
        public DbSet<PracticeFlashcard> PracticeFlashcards { get; set; }
        public DbSet<AmharicLetterFlashcard> LetterPracticeFlashcards { get; set; }

        public DbSet<PracticeMemoryGame> PracticeMemoryGames { get; set; }
        public DbSet<FlashCardLetter> FlashCardLetters { get; set; }
        public DbSet<AmharicWordFlashCard> AmharicWordFlashCards { get; set; }

        public DbSet<AmharicLetterMemoryGame> AmharicLetterMemoryGames { get; set; }
        public DbSet<AmharicWordMemoryGame> AmharicWordMemoryGames { get; set; }

        public DbSet<MemoryGameLetterSet> MemoryGameLetterSets { get; set; }

        public DbSet<AmharicWordImage> AmharicWordImages { get; set; }

        public DbSet<ExamModule> AssessmentModules { get; set; }
        public DbSet<AmharicLetterExam> AmharicLetterExams { get; set; }
        public DbSet<ExamSection> ExamSections { get; set; }
        public DbSet<ExamQuestion> ExamQuestions { get; set; }
        public DbSet<MultipleChoiceQuestion> MultipleChoiceQuestions { get; set; }

        public DbSet<CourseSubscription> CourseSubscriptions { get; set; }
        public DbSet<AmharicCoursePackage> AmharicCoursePackages { get; set; }

        public DbSet<NewsletterSubscription> NewsletterSubscriptions { get; set; }

    }
}
