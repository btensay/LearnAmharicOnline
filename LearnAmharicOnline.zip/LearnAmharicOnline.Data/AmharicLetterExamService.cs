﻿namespace LearnAmharicOnline.Data
{
    internal class AmharicLetterExamService
    {
    }
}