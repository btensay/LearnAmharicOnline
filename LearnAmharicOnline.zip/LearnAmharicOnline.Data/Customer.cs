﻿using LearnAmharicOnline.Core.Membership;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Web.Models
{
    //[Table("Customer")]
    public class Customer : User
    {
        private IList<CourseSubscription> PastSubscriptions;  //historic subscription the customer have had
        
        public Customer ()
        {            
            PastSubscriptions = new List<CourseSubscription>();
            NewsletterSubscription = new NewsletterSubscription();
            this.Address = new Address();
        }
 

        public virtual Address Address { get; set; } /* to revisit for residence and billing address distinctions */
        public virtual NewsletterSubscription NewsletterSubscription { get; set; }
        public virtual CourseSubscription CurrentCourseSubscription { get; set; }
        public virtual IList<CourseSubscription> HistoricSubscriptions 
        { 
                get
            {
                return PastSubscriptions;
            }
        }
    }
}


