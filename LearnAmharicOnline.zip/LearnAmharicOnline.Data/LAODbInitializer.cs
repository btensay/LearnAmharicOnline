﻿using System.Collections.Generic;
using System.Data.Entity;
using LearnAmharicOnline.Core.Domain;
namespace LearnAmharicOnline.Data
{
    public class LAODbInitializer : DropCreateDatabaseIfModelChanges<LearnAmharicOnlineDbContext>
    {
        public string UserName = string.Empty;
        public int CustomerId;

        protected override void Seed(LearnAmharicOnlineDbContext context)
        {
           /* var tempId = 1;
            var tempIdTwo = 2;
            var amharicLetters = new List<AmharicLetter>();

            var amLetterOne =    new AmharicLetter
                                                {
                                                    Id = tempId,
                                                    AmharicSymbol="ቀ",
                                                    EnglishReading = "Qea",
                                                    AudioUrl ="testUrl",
                                                    ImageUrl = "testUrl",
                                                    ColumnIndex =1,
                                                    RowIndex = 0
                                                };
            var exampleOne = new LearnAmharicOnline.Core.Domain.AmharicWord()
                                                {
                                                   Id = Guid.NewGuid(),
                                                   AmharicText ="ቀበቶ",
                                                   AudioUrl = "testUrl",
                                                   EnglishWordReading ="Qea.bea.to",
                                                   EnglishTranslation ="Belt"
                                                } ;

            amLetterOne.AddExampleWord(exampleOne);
            context.AmharicLetters.Add(amLetterOne);
            context.SaveChanges();

            var amLetterTwo = new AmharicLetter
                                            {
                                                Id = tempIdTwo,
                                                AmharicSymbol = "ፖ",
                                                EnglishReading = "Po",
                                                AudioUrl = "testUrl",
                                                ImageUrl = "testUrl",
                                                ColumnIndex = 2,
                                                RowIndex = 0
                                            };

            var exampleTwo =  new LearnAmharicOnline.Core.Domain.AmharicWord()
                                                {
                                                   Id = Guid.NewGuid(),
                                                   AmharicText ="ፖስታ", AudioUrl = "testUrl",
                                                   EnglishWordReading ="Po.s.ta",
                                                   EnglishTranslation ="Post/Envelop"
                                                } ;

            var exampleThree =   new LearnAmharicOnline.Core.Domain.AmharicWord()
                                                {
                                                   Id = Guid.NewGuid(),
                                                   AmharicText ="ስታ",
                                                   AudioUrl = "testUrl",
                                                   EnglishWordReading ="s.ta",
                                                   EnglishTranslation ="stapp"
                                                };

            amLetterTwo.AddExampleWord(exampleTwo);
            amLetterTwo.AddExampleWord(exampleThree);

            context.AmharicLetters.Add(amLetterTwo);
            context.SaveChanges();

            var tempList = new List<AmharicLetter>();
                tempList.Add(amLetterOne);

            var tempWordsList = new List<AmharicWord>();

            var thirdWordExample = new AmharicWord()
                                {
                                    Id = Guid.NewGuid(),
                                    AmharicText = "bado",
                                    EnglishWordReading = "ba.do",
                                    AudioUrl = "chu url",
                                    EnglishTranslation = "axum"
                                };

            tempWordsList.Add(thirdWordExample);
            amLetterTwo.AddExampleWord(thirdWordExample);

            var beginnerCourse = new BeginnerAmharicCourse()
                                    { AmharicLetters = tempList };

                context.AmharicCourses.Add(beginnerCourse);
                context.SaveChanges();


            // context.SaveChanges();
            var testSTop = string.Empty;

            var tempListTwo = new List<AmharicLetter>();
                tempListTwo.Add(amLetterTwo);

            var intermediateCourse = new IntermediateAmharicCourse()
                                {
                                    AmharicLetters = tempListTwo,
                                    AmharicWords = tempWordsList
                                };

            context.AmharicCourses.Add(intermediateCourse);
            context.SaveChanges();

            //data reading from db
            var dbAccessTest = context.AmharicCourses.OfType<BeginnerAmharicCourse>().ToList();

            var subscription = new CourseSubscription() { StartDate = (DateTime)DateTime.Now,
                                                            EndDate = (DateTime)DateTime.Now.AddYears(1),
                                                            Description = "Test Description",
                                                            Name = "Mukera subsc",
                                                            SubscriptionStatus = SubscriptionStatus.New,
                                                            AmharicCoursePackage = intermediateCourse
                                                        };
            var subscTemp = subscription;
            context.CourseSubscriptions.Add(subscription);*/
            //context.SaveChanges();


           /* var customer = new Customer();
            customer.CurrentCourseSubscription = subscTemp;
            customer.PersonalDetails = new PersonalDetail();
            context.Users.Add(customer);
            context.SaveChanges();*/
        }


        //Populate Amharic letters
        private IList<AmharicLetter> GetAmharicLetters()
        {
            var lettersList = new List<AmharicLetter>();

     lettersList.Add(new AmharicLetter {Id = 1, AmharicSymbol = "ፖ", EnglishReading = "Po",
                                        AudioUrl = "testUrl", ImageUrl = "testUrl",ColumnIndex = 2, RowIndex = 0 });


            return lettersList;
        }

       /* public static void AddAmharicNumerals(LearnAmharicOnlineDbContext context)
        {
            var test = string.Empty;

        context.AmharicNumerals.Add(new AmharicNumeral(){Id = 1, AmharicNumeralSymbol = "፩", AmharicReading="eaa.ne.de",
                                                            ArabicNumeralSymbol = "1", AudioUrl ="test numberUrl", EnglishReading="One"});

        context.AmharicNumerals.Add(new AmharicNumeral(){Id = 2, AmharicNumeralSymbol = "፪", AmharicReading = "hu.lea.te",                                                     ArabicNumeralSymbol = "2", AudioUrl = "test numberUrl",EnglishReading = "Two"});

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 3, AmharicNumeralSymbol = "፫", AmharicReading = "so.se.te", ArabicNumeralSymbol = "3", AudioUrl = "test numberUrl", EnglishReading = "Three" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 4, AmharicNumeralSymbol = "፬", AmharicReading = "eaa.ra.te", ArabicNumeralSymbol = "4", AudioUrl = "test numberUrl", EnglishReading = "Four" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 5, AmharicNumeralSymbol = "፭", AmharicReading = "eaa.me.se.te", ArabicNumeralSymbol = "5", AudioUrl = "test numberUrl", EnglishReading = "Five" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 6, AmharicNumeralSymbol = "፮", AmharicReading = "se.de.se.te", ArabicNumeralSymbol = "6", AudioUrl = "test numberUrl", EnglishReading = "Six" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 7, AmharicNumeralSymbol = "፯", AmharicReading = "sea.ba.te", ArabicNumeralSymbol = "7", AudioUrl = "test numberUrl", EnglishReading = "Seven" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 8, AmharicNumeralSymbol = "፰", AmharicReading = "se.me.ne.te", ArabicNumeralSymbol = "8", AudioUrl = "test numberUrl", EnglishReading = "Eight" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 9, AmharicNumeralSymbol = "፱", AmharicReading = "zea.ttea.gne", ArabicNumeralSymbol = "9", AudioUrl = "test numberUrl", EnglishReading = "Nine" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 10, AmharicNumeralSymbol = "፲", AmharicReading = "eaa.se.re", ArabicNumeralSymbol = "10", AudioUrl = "test numberUrl", EnglishReading = "Ten" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 11, AmharicNumeralSymbol = "፳", AmharicReading = "ha.ya", ArabicNumeralSymbol = "20", AudioUrl = "test numberUrl", EnglishReading = "Twenty" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 12, AmharicNumeralSymbol = "፴", AmharicReading = "sea.la.sa", ArabicNumeralSymbol = "30", AudioUrl = "test numberUrl", EnglishReading = "Thirty" });

        context.AmharicNumerals.Add(new AmharicNumeral() { Id = 13, AmharicNumeralSymbol = "፵", AmharicReading = "eaa.re.ba", ArabicNumeralSymbol = "40", AudioUrl = "test numberUrl", EnglishReading = "Fourty" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 14, AmharicNumeralSymbol = "፶", AmharicReading = "ha.me.sa", ArabicNumeralSymbol = "50", AudioUrl = "test numberUrl", EnglishReading = "Fifty" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 15, AmharicNumeralSymbol = "፷", AmharicReading = "se.le.sa", ArabicNumeralSymbol = "60", AudioUrl = "test numberUrl", EnglishReading = "Sixty" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 16, AmharicNumeralSymbol = "፸", AmharicReading = "sea.ba", ArabicNumeralSymbol = "70", AudioUrl = "test numberUrl", EnglishReading = "Seventy" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 17, AmharicNumeralSymbol = "፹", AmharicReading = "sea.ma.ne.ya", ArabicNumeralSymbol = "80", AudioUrl = "test numberUrl", EnglishReading = "Eighty" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 18, AmharicNumeralSymbol = "፺", AmharicReading = "zea.ttea.na", ArabicNumeralSymbol = "90", AudioUrl = "test numberUrl", EnglishReading = "Ninty" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 19, AmharicNumeralSymbol = "፻", AmharicReading = "mea.to", ArabicNumeralSymbol = "100", AudioUrl = "test numberUrl", EnglishReading = "Hundred" });

       context.AmharicNumerals.Add(new AmharicNumeral() { Id = 20, AmharicNumeralSymbol = "፼", AmharicReading = "shi", ArabicNumeralSymbol = "1000", AudioUrl = "test numberUrl", EnglishReading = "Thousand" });

       context.SaveChanges();
        }*/
    }
}
