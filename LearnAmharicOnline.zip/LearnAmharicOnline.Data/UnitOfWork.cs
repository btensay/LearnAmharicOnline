﻿using LearnAmharicOnline.Core;
using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using LearnAmharicOnline.Core.Membership;
using System;
using System.Activities.Statements;
using System.Data.Entity;

namespace LearnAmharicOnline.Data
{
    public class UnitOfWork : IDisposable, IUnitOfWork
    {
        private IRepository<AmharicLetter> _amharicLetterRepo;
        private IRepository<AmharicWord> _amharicWordRepo;
        private IRepository<AmharicLetterExam> _amharicLetterExamRepo;
        private IRepository<LetterLearningModule> _letterLearningModuleRepo;

        private IRepository<AmharicLetterFlashcard> _letterPracticeFlashcardRepo;
        private IRepository<FlashCardLetter> _flashCardLetterRepo;
        private IRepository<AmharicLetterMemoryGame> _letterMemoryGameModuleRepo;

        private IRepository<ExamQuestion> _examQuestionRepo;
        private IRepository<ExamSection> _examSectionRepo;

        private IRepository<AmharicCoursePackage> _amharicCoursePackageRepo;
        private IRepository<AmharicCourseModule> _amharicCourseModuleRepo;
        private IRepository<CourseSubscription> _courseSubscriptionRepo;
        private IRepository<Customer> _customerRepo;

        private DbContext _dbContext = new LearnAmharicOnlineDbContext();
        private bool _disposed = false;

        public DbContext DbContext()
        {
           return _dbContext;
        }

        public void Commit()
        {
            _dbContext.SaveChanges();
        }

        public void Rollback()
        {
            throw new NotImplementedException();
        }

        public IRepository<Customer> CustomerRepo
        {
            get
            {
                if (_customerRepo == null)
                {
                    _customerRepo = new LAORepository<Customer>(_dbContext);
                }
                return _customerRepo;
            }
        }

        public IRepository<AmharicCoursePackage> AmharicCoursePackageRepo
        {
            get
            {
                if (_amharicCoursePackageRepo == null)
                {
                    _amharicCoursePackageRepo = new LAORepository<AmharicCoursePackage>(_dbContext);
                }
                return _amharicCoursePackageRepo;
            }
        }

        public IRepository<LetterLearningModule> LetterLearningModuleRepository
        {
            get
            {
                if(_letterLearningModuleRepo == null)
                {
                    _letterLearningModuleRepo = new LAORepository<LetterLearningModule>(_dbContext);
                }
                return _letterLearningModuleRepo;
            }
        }

        public IRepository<AmharicLetter> AmharicLetterRepository
        {
            get
            {
                if (_amharicLetterRepo == null)
                {
                    _amharicLetterRepo = new LAORepository<AmharicLetter>(_dbContext);
                }
                return _amharicLetterRepo;
            }
        }

        public IRepository<AmharicWord> AmharicWordRepository
        {
            get
            {
                if (_amharicWordRepo == null)
                {
                    _amharicWordRepo = new LAORepository<AmharicWord>(_dbContext);
                }
                return _amharicWordRepo;
            }
        }

        public IRepository<AmharicLetterExam> AmharicLetterExamRepo
        {
            get
            {
                if (_amharicLetterExamRepo == null)
                {
                    _amharicLetterExamRepo = new LAORepository<AmharicLetterExam>(_dbContext);
                }
                return _amharicLetterExamRepo;
            }
        }

        public IRepository<AmharicLetterFlashcard> LetterPracticeFlashcardRepo
        {
            get
            {
                if (_letterPracticeFlashcardRepo == null)
                {
                    _letterPracticeFlashcardRepo = new LAORepository<AmharicLetterFlashcard>(_dbContext);
                }
                return _letterPracticeFlashcardRepo;
            }
        }

        public IRepository<FlashCardLetter> FlashCardLetterRepo
        {
            get
            {
                if (_flashCardLetterRepo == null)
                {
                    _flashCardLetterRepo = new LAORepository<FlashCardLetter>(_dbContext);
                }
                return _flashCardLetterRepo;
            }
        }

        public IRepository<AmharicLetterMemoryGame> LetterMemoryGameModuleRepo
        {
            get
            {
                if (_letterMemoryGameModuleRepo == null)
                {
                    _letterMemoryGameModuleRepo = new LAORepository<AmharicLetterMemoryGame>(_dbContext);
                }
                return _letterMemoryGameModuleRepo;
            }
        }

        public IRepository<ExamQuestion> ExamQuestionRepo
        {
            get
            {
                if (_examQuestionRepo == null)
                {
                    _examQuestionRepo = new LAORepository<ExamQuestion>(_dbContext);
                }
                return _examQuestionRepo;
            }
        }

        public IRepository<ExamSection> ExamSectionRepo
        {
            get
            {
                if (_examSectionRepo == null)
                {
                    _examSectionRepo = new LAORepository<ExamSection>(_dbContext);
                }
                return _examSectionRepo;
            }
        }

        public IRepository<AmharicCourseModule> AmharicCourseModuleRepo
        {
            get
            {
                if (_amharicCourseModuleRepo == null)
                {
                    _amharicCourseModuleRepo = new LAORepository<AmharicCourseModule>(_dbContext);
                }
                return _amharicCourseModuleRepo;
            }
        }

        public IRepository<CourseSubscription> CourseSubscriptionRepo
        {
            get
            {
                if (_courseSubscriptionRepo == null)
                {
                    _courseSubscriptionRepo = new LAORepository<CourseSubscription>(_dbContext);
                }
                return _courseSubscriptionRepo;
            }
        }


        protected virtual void Dispose(bool disposing)
        {
            if (!this._disposed)
            {
                if (disposing)
                {
                    _dbContext.Dispose();
                }
            }
            this._disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
