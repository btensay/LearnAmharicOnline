﻿using LearnAmharicOnline.Core;
using LearnAmharicOnline.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Services
{
    public partial class LAOServiceProvider<T> : ILAOServiceProvider<T> where T : LAOService
    {
        private IUnitOfWork<BaseEntity> _currentUniteOfWork;

        public LAOServiceProvider(IUnitOfWork<BaseEntity> unitOfWork)
        {
            _currentUniteOfWork = unitOfWork;
        }

          public T GetService(Type type)
        {
            var service = (T) new LAOService(); // _currentUniteOfWork.RepositoryOfType(typeof(T));
            return service;
        }
    }
}
