﻿using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicPracticeResource
{
    /// <summary>
    ///  Amharic FlashCard Letter Letter Service interface
    /// </summary>
    public partial interface IFlashCardLetterService
    {
        /// <summary>
        /// Inserts an Amharic FlashCard Letter
        /// </summary>
        /// <param name="flashCardLetter">Amharic FlashCard Letter</param>
        void InsertFlashCardLetter(FlashCardLetter flashCardLetter);

        /// <summary>
        /// Updates the Amharic FlashCard Letter
        /// </summary>
        /// <param name="flashCardLetter">Amharic FlashCard Letter</param>
        void UpdateFlashCardLetter(FlashCardLetter flashCardLetter);

        /// <summary>
        /// Deletes an  Amharic FlashCard Letter
        /// </summary>
        /// <param name="flashCardLetter">Amharic FlashCard Letter</param>
        void DeleteFlashCardLetter(FlashCardLetter flashCardLetter);

        /// <summary>
        /// Gets a Letter Learning Module
        /// </summary>
        /// <param name="flashCardLetterId">Letter Learning Module identifier</param>
        /// <returns>Amharic FlashCard Letters</returns>
        FlashCardLetter GetFlashCardLetterById(int flashCardLetterId);

        /// <summary>
        /// Gets all  Amharic FlashCard Letters
        /// </summary>
        /// <returns> Amharic FlashCard Letters</returns>
        IList<FlashCardLetter> GetAllFlashCardLetters();

    }
}
