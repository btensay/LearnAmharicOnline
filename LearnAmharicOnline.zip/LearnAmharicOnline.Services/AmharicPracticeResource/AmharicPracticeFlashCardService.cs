﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicPracticeResource
{
    public partial class AmharicPracticeFlashCardService : IAmharicPracticeFlashCardService
    {
        #region Fields
        private readonly IRepository<AmharicLetterFlashcard> _letterPracticeFlashcardRepository;
        #endregion

        #region Ctor

        public AmharicPracticeFlashCardService(IRepository<AmharicLetterFlashcard> letterPracticeFlashcardRepository)
        {
            _letterPracticeFlashcardRepository = letterPracticeFlashcardRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Letter Practice Flashcard
        /// </summary>
        /// <param name="letterPracticeFlashcard">Letter Practice Flashcard</param>
        public virtual void InsertLetterPracticeFlashcard(AmharicLetterFlashcard letterPracticeFlashcard)
        {
            if(letterPracticeFlashcard == null)
            {
                throw new ArgumentNullException("Letter Practice Flashcard Module");
            }

            _letterPracticeFlashcardRepository.Insert(letterPracticeFlashcard);
        }

        /// <summary>
        /// Updates the  Letter Practice Flashcard
        /// </summary>
        /// <param name="LetterPracticeFlashcard">Letter Practice Flashcard</param>
        public virtual void UpdateLetterPracticeFlashcard(AmharicLetterFlashcard letterPracticeFlashcard)
        {
            _letterPracticeFlashcardRepository.Update(letterPracticeFlashcard);
        }

        /// <summary>
        /// Deletes an  Letter Practice Flashcard
        /// </summary>
        /// <param name="AmharicCourseModule"> Letter Practice Flashcard</param>
        public virtual void DeleteLetterPracticeFlashcard(AmharicLetterFlashcard letterPracticeFlashcard)
        {

        }

        /// <summary>
        /// Gets an  Letter Practice Flashcard
        /// </summary>
        /// <param name="letterPracticeFlashcardId"> Letter Practice Flashcard identifier</param>
        /// <returns> Letter Practice Flashcard</returns>
        public virtual AmharicLetterFlashcard GetLetterPracticeFlashcardById(int letterPracticeFlashcardId)
        {
            return _letterPracticeFlashcardRepository.GetById(letterPracticeFlashcardId);
        }

        public virtual IList<AmharicLetterFlashcard> GetAllLetterPracticeFlashcards()
        {
            return _letterPracticeFlashcardRepository.GetAll().ToList();
        }

    }
}
