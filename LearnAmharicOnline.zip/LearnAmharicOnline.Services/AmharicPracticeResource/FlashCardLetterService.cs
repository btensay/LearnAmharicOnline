﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicPracticeResource
{
    public partial class FlashCardLetterService : IFlashCardLetterService
    {
        #region Fields
        private readonly IRepository<FlashCardLetter> _flashcardLetterRepository;
        #endregion

        #region Ctor

        public FlashCardLetterService(IRepository<FlashCardLetter> flashcardLetterRepository)
        {
            _flashcardLetterRepository = flashcardLetterRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Letter Practice Flashcard
        /// </summary>
        /// <param name="flashcardLetter">Letter Practice Flashcard</param>
        public virtual void InsertFlashCardLetter(FlashCardLetter flashcardLetter)
        {
            if (flashcardLetter == null)
            {
                throw new ArgumentNullException("Letter Practice Flashcard Module");
            }

            _flashcardLetterRepository.Insert(flashcardLetter);
        }

        /// <summary>
        /// Updates the  Letter Practice Flashcard
        /// </summary>
        /// <param name="FlashCardLetter">Letter Practice Flashcard</param>
        public virtual void UpdateFlashCardLetter(FlashCardLetter flashcardLetter)
        {
            _flashcardLetterRepository.Update(flashcardLetter);
        }

        /// <summary>
        /// Deletes an  Letter Practice Flashcard
        /// </summary>
        /// <param name="AmharicCourseModule"> Letter Practice Flashcard</param>
        public virtual void DeleteFlashCardLetter(FlashCardLetter flashcardLetter)
        {

        }

        /// <summary>
        /// Gets an  Letter Practice Flashcard
        /// </summary>
        /// <param name="flashcardLetterId"> Letter Practice Flashcard identifier</param>
        /// <returns> Letter Practice Flashcard</returns>
        public virtual FlashCardLetter GetFlashCardLetterById(int flashcardLetterId)
        {
            return _flashcardLetterRepository.GetById(flashcardLetterId);
        }

        public virtual IList<FlashCardLetter> GetAllFlashCardLetters()
        {
            return _flashcardLetterRepository.GetAll().ToList();
        }
    }
}
