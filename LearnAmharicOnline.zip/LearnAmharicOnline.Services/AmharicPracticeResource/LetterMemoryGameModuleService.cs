﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicPracticeResource
{
    public partial class LetterMemoryGameModuleService : ILetterMemoryGameModuleService
    {
        #region Fields
        private readonly IRepository<AmharicLetterMemoryGame> _letterMemoryGameModuleRepository;
        #endregion

        #region Ctor

        public LetterMemoryGameModuleService(IRepository<AmharicLetterMemoryGame> letterMemoryGameModuleRepository)
        {
            _letterMemoryGameModuleRepository = letterMemoryGameModuleRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Letter Memory Game Module
        /// </summary>
        /// <param name="letterMemoryGameModule">Letter Memory Game Module</param>
        public virtual void InsertLetterMemoryGameModule(AmharicLetterMemoryGame letterMemoryGameModule)
        {
            if (letterMemoryGameModule == null)
            {
                throw new ArgumentNullException("Letter Memory Game Module Module");
            }

            _letterMemoryGameModuleRepository.Insert(letterMemoryGameModule);
        }

        /// <summary>
        /// Updates the  Letter Memory Game Module
        /// </summary>
        /// <param name="LetterMemoryGameModule">Letter Memory Game Module</param>
        public virtual void UpdateLetterMemoryGameModule(AmharicLetterMemoryGame letterMemoryGameModule)
        {
            _letterMemoryGameModuleRepository.Update(letterMemoryGameModule);
        }

        /// <summary>
        /// Deletes an  Letter Memory Game Module
        /// </summary>
        /// <param name="AmharicCourseModule"> Letter Memory Game Module</param>
        public virtual void DeleteLetterMemoryGameModule(AmharicLetterMemoryGame letterMemoryGameModule)
        {

        }

        /// <summary>
        /// Gets an  Letter Memory Game Module
        /// </summary>
        /// <param name="letterMemoryGameModuleId"> Letter Memory Game Module identifier</param>
        /// <returns> Letter Memory Game Module</returns>
        public virtual AmharicLetterMemoryGame GetLetterMemoryGameModuleById(int letterMemoryGameModuleId)
        {
            return _letterMemoryGameModuleRepository.GetById(letterMemoryGameModuleId);
        }

        public virtual IList<AmharicLetterMemoryGame> GetAllLetterMemoryGameModules()
        {
            return _letterMemoryGameModuleRepository.GetAll().ToList();
        }
    }
}
