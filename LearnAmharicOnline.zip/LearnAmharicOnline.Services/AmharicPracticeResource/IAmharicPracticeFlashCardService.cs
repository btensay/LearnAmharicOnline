﻿using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicPracticeResource
{
    /// <summary>
    ///  Amharic Practice FlashCard service interface
    /// </summary>
    public partial interface IAmharicPracticeFlashCardService
    {
        /// <summary>
        /// Inserts an Amharic Practice FlashCard
        /// </summary>
        /// <param name="letterPracticeFlashcard">Amharic Practice FlashCard</param>
        void InsertLetterPracticeFlashcard(AmharicLetterFlashcard letterPracticeFlashcard);

        /// <summary>
        /// Updates the Amharic Practice FlashCard
        /// </summary>
        /// <param name="letterPracticeFlashcard">Amharic Practice FlashCard</param>
        void UpdateLetterPracticeFlashcard(AmharicLetterFlashcard letterPracticeFlashcard);

        /// <summary>
        /// Deletes an  Amharic Practice FlashCard
        /// </summary>
        /// <param name="letterPracticeFlashcard">Amharic Practice FlashCard</param>
        void DeleteLetterPracticeFlashcard(AmharicLetterFlashcard letterPracticeFlashcard);

        /// <summary>
        /// Gets a Letter Learning Module
        /// </summary>
        /// <param name="letterPracticeFlashcardId">Letter Learning Module identifier</param>
        /// <returns>Amharic Practice FlashCards</returns>
        AmharicLetterFlashcard GetLetterPracticeFlashcardById(int letterPracticeFlashcardId);

        /// <summary>
        /// Gets all  Amharic Practice FlashCards
        /// </summary>
        /// <returns> Amharic Practice FlashCards</returns>
        IList<AmharicLetterFlashcard> GetAllLetterPracticeFlashcards();

    }
}
