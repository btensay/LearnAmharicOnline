﻿using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicPracticeResource
{
    /// <summary>
    ///  Amharic Letter Memory Game Module
    /// </summary>
    public partial interface ILetterMemoryGameModuleService
    {
        /// <summary>
        /// Inserts an Amharic Letter Memory Game Module
        /// </summary>
        /// <param name="letterMemoryGameModule">Amharic Letter Memory Game Module</param>
        void InsertLetterMemoryGameModule(AmharicLetterMemoryGame letterMemoryGameModule);

        /// <summary>
        /// Updates the Amharic Letter Memory Game Module
        /// </summary>
        /// <param name="letterMemoryGameModule">Amharic Letter Memory Game Module</param>
        void UpdateLetterMemoryGameModule(AmharicLetterMemoryGame letterMemoryGameModule);

        /// <summary>
        /// Deletes an  Amharic Letter Memory Game Module
        /// </summary>
        /// <param name="letterMemoryGameModule">Amharic Letter Memory Game Module</param>
        void DeleteLetterMemoryGameModule(AmharicLetterMemoryGame letterMemoryGameModule);

        /// <summary>
        /// Gets a Letter Learning Module
        /// </summary>
        /// <param name="letterMemoryGameModuleId">Letter Learning Module identifier</param>
        /// <returns>Amharic Letter Memory Game Modules</returns>
        AmharicLetterMemoryGame GetLetterMemoryGameModuleById(int letterMemoryGameModuleId);

        /// <summary>
        /// Gets all  Amharic Letter Memory Game Modules
        /// </summary>
        /// <returns> Amharic Letter Memory Game Modules</returns>
        IList<AmharicLetterMemoryGame> GetAllLetterMemoryGameModules();

    }
}
