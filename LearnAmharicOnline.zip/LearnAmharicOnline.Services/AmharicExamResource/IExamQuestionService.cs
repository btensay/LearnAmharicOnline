﻿using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicExamResource
{
    /// <summary>
    ///  Amharic Exam Question Service interface
    /// </summary>
    public partial interface IExamQuestionService
    {
        /// <summary>
        /// Inserts an Amharic Exam Question
        /// </summary>
        /// <param name="examQuestion">Amharic Exam Question</param>
        void InsertExamQuestion(ExamQuestion examQuestion);

        /// <summary>
        /// Updates the Amharic Exam Question
        /// </summary>
        /// <param name="examQuestion">Amharic Exam Question</param>
        void UpdateExamQuestion(ExamQuestion examQuestion);

        /// <summary>
        /// Deletes an  Amharic Exam Question
        /// </summary>
        /// <param name="examQuestion">Amharic Exam Question</param>
        void DeleteExamQuestion(ExamQuestion examQuestion);

        /// <summary>
        /// Gets a Exam Question
        /// </summary>
        /// <param name="examQuestionId">Exam Question identifier</param>
        /// <returns>Amharic Exam Questions</returns>
        ExamQuestion GetExamQuestionById(int examQuestionId);

        /// <summary>
        /// Gets all  Amharic Exam Questions
        /// </summary>
        /// <returns> Amharic Exam Questions</returns>
        IList<ExamQuestion> GetAllExamQuestions();

    }
}
