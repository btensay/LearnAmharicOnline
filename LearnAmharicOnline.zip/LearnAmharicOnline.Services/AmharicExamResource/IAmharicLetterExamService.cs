﻿using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicExamResource
{
    /// <summary>
    ///  Amharic Letter Learning Module service interface
    /// </summary>
    public partial interface IAmharicLetterExamService
    {
        /// <summary>
        /// Inserts an Amharic Letter Learning Module
        /// </summary>
        /// <param name="amharicExamModule">Amharic Letter Learning Module</param>
        void InsertAmharicLetterExam(AmharicLetterExam amharicExamModule);

        /// <summary>
        /// Updates the Amharic Letter Learning Module
        /// </summary>
        /// <param name="amharicExamModule">Amharic Letter Learning Module</param>
        void UpdateAmharicLetterExam(AmharicLetterExam amharicExamModule);

        /// <summary>
        /// Deletes an  Amharic Letter Learning Module
        /// </summary>
        /// <param name="amharicExamModule">Amharic Letter Learning Module</param>
        void DeleteAmharicLetterExam(AmharicLetterExam amharicExamModule);

        /// <summary>
        /// Gets a Letter Learning Module
        /// </summary>
        /// <param name="amharicExamModuleId">Letter Learning Module identifier</param>
        /// <returns>Amharic Letter Learning Modules</returns>
        AmharicLetterExam GetAmharicLetterExamById(int amharicExamModuleId);

        /// <summary>
        /// Gets all  Amharic Letter Learning Modules
        /// </summary>
        /// <returns> Amharic Letter Learning Modules</returns>
        IList<AmharicLetterExam> GetAllAmharicLetterExams();

    }
}
