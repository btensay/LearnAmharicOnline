﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicExamResource
{
    public partial class AmharicLetterExamService : IAmharicLetterExamService
    {
        #region Fields
        private readonly IRepository<AmharicLetterExam> _amharicExamModuleRepository;
        #endregion

        #region Ctor

        public AmharicLetterExamService(IRepository<AmharicLetterExam> amharicExamModuleRepository)
        {
            _amharicExamModuleRepository = amharicExamModuleRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Amharic Letter Exam Module
        /// </summary>
        /// <param name="amharicExamModule">Amharic Letter Exam Module</param>
        public virtual void InsertAmharicLetterExam(AmharicLetterExam amharicExamModule)
        {
            if(amharicExamModule == null)
            {
                throw new ArgumentNullException("Amharic Letter Exam");
            }

            _amharicExamModuleRepository.Insert(amharicExamModule);
        }

        /// <summary>
        /// Updates the  Amharic Letter Exam
        /// </summary>
        /// <param name="AmharicLetterExam">Amharic Letter Exam</param>
        public virtual void UpdateAmharicLetterExam(AmharicLetterExam amharicExamModule)
        {
            _amharicExamModuleRepository.Update(amharicExamModule);
        }

        /// <summary>
        /// Deletes an  Amharic Letter Exam
        /// </summary>
        /// <param name="AmharicCourseModule"> Amharic Letter Exam</param>
        public virtual void DeleteAmharicLetterExam(AmharicLetterExam amharicExamModule)
        {

        }

        /// <summary>
        /// Gets an Amharic Letter Exam
        /// </summary>
        /// <param name="amharicExamModuleId"> Amharic Letter Exam identifier</param>
        /// <returns> Amharic Letter Exam</returns>
        public virtual AmharicLetterExam GetAmharicLetterExamById(int amharicExamModuleId)
        {
            return _amharicExamModuleRepository.GetById(amharicExamModuleId);
        }

        public virtual IList<AmharicLetterExam> GetAllAmharicLetterExams()
        {
            return _amharicExamModuleRepository.GetAll().ToList();
        }

    }
}
