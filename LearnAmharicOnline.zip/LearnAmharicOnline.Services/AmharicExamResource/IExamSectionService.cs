﻿using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicExamResource
{
    /// <summary>
    ///  Amharic Exam Section Service interface
    /// </summary>
    public partial interface IExamSectionService
    {
        /// <summary>
        /// Inserts an Amharic Exam Section
        /// </summary>
        /// <param name="examSection">Amharic Exam Section</param>
        void InsertExamSection(ExamSection examSection);

        /// <summary>
        /// Updates the Amharic Exam Section
        /// </summary>
        /// <param name="examSection">Amharic Exam Section</param>
        void UpdateExamSection(ExamSection examSection);

        /// <summary>
        /// Deletes an  Amharic Exam Section
        /// </summary>
        /// <param name="examSection">Amharic Exam Section</param>
        void DeleteExamSection(ExamSection examSection);

        /// <summary>
        /// Gets a Exam Section
        /// </summary>
        /// <param name="examSectionId">Exam Section identifier</param>
        /// <returns>Amharic Exam Sections</returns>
        ExamSection GetExamSectionById(int examSectionId);

        /// <summary>
        /// Gets all  Amharic Exam Sections
        /// </summary>
        /// <returns> Amharic Exam Sections</returns>
        IList<ExamSection> GetAllExamSections();

    }
}
