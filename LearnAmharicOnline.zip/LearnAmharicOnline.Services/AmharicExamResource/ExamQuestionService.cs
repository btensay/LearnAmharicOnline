﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicExamResource
{
    public partial class ExamQuestionService : IExamQuestionService
    {
        #region Fields
        private readonly IRepository<ExamQuestion> _examQuestionRepository;
        #endregion

        #region Ctor

        public ExamQuestionService(IRepository<ExamQuestion> examQuestionRepository)
        {
            _examQuestionRepository = examQuestionRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Amharic Exam Question
        /// </summary>
        /// <param name="examQuestion">Amharic Exam Question</param>
        public virtual void InsertExamQuestion(ExamQuestion examQuestion)
        {
            if(examQuestion == null)
            {
                throw new ArgumentNullException("Amharic Exam Question");
            }

            _examQuestionRepository.Insert(examQuestion);
        }

        /// <summary>
        /// Updates the  Amharic Exam Question
        /// </summary>
        /// <param name="ExamQuestion">Amharic Exam Question</param>
        public virtual void UpdateExamQuestion(ExamQuestion examQuestion)
        {
            _examQuestionRepository.Update(examQuestion);
        }

        /// <summary>
        /// Deletes an  Amharic Exam Question
        /// </summary>
        /// <param name="examQuestion"> Amharic Exam Question</param>
        public virtual void DeleteExamQuestion(ExamQuestion examQuestion)
        {

        }

        /// <summary>
        /// Gets an Amharic Exam Question
        /// </summary>
        /// <param name="examQuestionId"> Amharic Exam Question identifier</param>
        /// <returns> Amharic Exam Question</returns>
        public virtual ExamQuestion GetExamQuestionById(int examQuestionId)
        {
            return _examQuestionRepository.GetById(examQuestionId);
        }

        public virtual IList<ExamQuestion> GetAllExamQuestions()
        {
            return _examQuestionRepository.GetAll().ToList();
        }

    }
}
