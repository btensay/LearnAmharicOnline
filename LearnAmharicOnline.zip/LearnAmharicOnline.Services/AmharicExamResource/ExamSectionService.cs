﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicExamResource
{
    public partial class ExamSectionService : IExamSectionService
    {
        #region Fields
        private readonly IRepository<ExamSection> _examSectionRepository;
        #endregion

        #region Ctor

        public ExamSectionService(IRepository<ExamSection> examSectionRepository)
        {
            _examSectionRepository = examSectionRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Amharic Letter Exam Module
        /// </summary>
        /// <param name="examSection">Amharic Letter Exam Module</param>
        public virtual void InsertExamSection(ExamSection examSection)
        {
            if(examSection == null)
            {
                throw new ArgumentNullException("Amharic Letter Exam");
            }

            _examSectionRepository.Insert(examSection);
        }

        /// <summary>
        /// Updates the  Amharic Letter Exam
        /// </summary>
        /// <param name="ExamSection">Amharic Letter Exam</param>
        public virtual void UpdateExamSection(ExamSection examSection)
        {
            _examSectionRepository.Update(examSection);
        }

        /// <summary>
        /// Deletes an  Amharic Letter Exam
        /// </summary>
        /// <param name="examSection"> Amharic Letter Exam</param>
        public virtual void DeleteExamSection(ExamSection examSection)
        {

        }

        /// <summary>
        /// Gets an Amharic Letter Exam
        /// </summary>
        /// <param name="examSectionId"> Amharic Letter Exam identifier</param>
        /// <returns> Amharic Letter Exam</returns>
        public virtual ExamSection GetExamSectionById(int examSectionId)
        {
            return _examSectionRepository.GetById(examSectionId);
        }

        public virtual IList<ExamSection> GetAllExamSections()
        {
            return _examSectionRepository.GetAll().ToList();
        }

    }
}
