﻿using LearnAmharicOnline.Services.AmharicCourseModules;
using LearnAmharicOnline.Services.AmharicCoursePackages;
using LearnAmharicOnline.Services.AmharicExamResource;
using LearnAmharicOnline.Services.AmharicLearningResource;
using LearnAmharicOnline.Services.AmharicLetters;
using LearnAmharicOnline.Services.AmharicPracticeResource;
using LearnAmharicOnline.Services.AmharicWords;
using LearnAmharicOnline.Services.Customers;
using LearnAmharicOnline.Services.Subscriptions;

namespace LearnAmharicOnline.Services
{
    public partial interface IAmharicServiceProvider
    {
        IAmharicLetterLearningService AmharicLetterLearningService { get; }
        IAmharicLettersService AmharicLettersService { get; }
        IAmharicWordsService AmharicWordsService { get; }
        IAmharicLetterExamService AmharicLetterExamService { get; }

        IAmharicPracticeFlashCardService AmharicPracticeFlashCardService { get; }
        IFlashCardLetterService FlashCardLetterService { get; }
        ILetterMemoryGameModuleService LetterMemoryGameModuleService { get; }

        IExamSectionService ExamSectionService { get; }
        IExamQuestionService ExamQuestionService { get; }

        IAmharicCoursePackageService AmharicCoursePackageService { get; }
        IAmharicCourseModuleService AmharicCourseModuleService { get; }
        ICourseSubscriptionsService CourseSubscriptionsService { get; }

        ICustomerService CustomerService { get; }
    }
}
