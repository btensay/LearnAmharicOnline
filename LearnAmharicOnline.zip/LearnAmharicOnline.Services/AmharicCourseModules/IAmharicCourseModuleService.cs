﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicCourseModules
{
    /// <summary>
    /// Amharic Course Modules service interface
    /// </summary>
    public partial interface IAmharicCourseModuleService
    {
        /// <summary>
        /// Inserts an Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModule">Amharic Course Package</param>
        void InsertAmharicCourseModule(AmharicCourseModule AmharicCourseModule);

        /// <summary>
        /// Updates the Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModule">Amharic Course Package</param>
        void UpdateAmharicCourseModule(AmharicCourseModule AmharicCourseModule);

        /// <summary>
        /// Deletes an Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModule">Amharic Course Package</param>
        void DeleteAmharicCourseModule(AmharicCourseModule AmharicCourseModule);

        /// <summary>
        /// Gets an Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModuleId">Amharic Course Module identifier</param>
        /// <returns>Amharic Course Module</returns>
        AmharicCourseModule GetAmharicCourseModuleById(int AmharicCourseModuleId);

        /// <summary>
        /// Gets all Amharic Course Modules
        /// </summary>
        /// <returns>Amharic Course Modules</returns>
        IList<AmharicCourseModule> GetAllAmharicCourseModules();
    }
}
