﻿using LearnAmharicOnline.Core;
using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Services.AmharicCourseModules
{
    public partial class AmharicCourseModuleService : IAmharicCourseModuleService
    {
        #region Fields
        private readonly IRepository<AmharicCourseModule> _amharicCourseModuleRepository;
        #endregion

        #region Ctor

        public AmharicCourseModuleService(IRepository<AmharicCourseModule> amharicCourseModuleRepository)
        {
            this._amharicCourseModuleRepository = amharicCourseModuleRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModule">Amharic Course Module</param>
        public virtual void InsertAmharicCourseModule(AmharicCourseModule amharicCourseModule)
        {
            if(amharicCourseModule == null)
            {
                throw new ArgumentNullException("AmharicCourseModule");
            }

            _amharicCourseModuleRepository.Insert(amharicCourseModule);

            //event notification
            //_eventPublisher.EntityInserted(blogPost);
        }

        /// <summary>
        /// Updates the Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModule">Amharic Course Package</param>
        public virtual void UpdateAmharicCourseModule(AmharicCourseModule amharicCourseModule)
        {
            _amharicCourseModuleRepository.Update(amharicCourseModule);
        }

        /// <summary>
        /// Deletes an Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModule">Amharic Course Module</param>
        public virtual void DeleteAmharicCourseModule(AmharicCourseModule amharicCourseModule)
        {

        }

        /// <summary>
        /// Gets an Amharic Course Module
        /// </summary>
        /// <param name="AmharicCourseModuleId">Amharic Course Module identifier</param>
        /// <returns>Amharic Course Module</returns>
        public virtual AmharicCourseModule GetAmharicCourseModuleById(int amharicCourseModuleId)
        {
            return _amharicCourseModuleRepository.GetById(amharicCourseModuleId);
        }

        public virtual IList<AmharicCourseModule> GetAllAmharicCourseModules()
        {
            return _amharicCourseModuleRepository.GetAll().ToList();
        }
    }
}
