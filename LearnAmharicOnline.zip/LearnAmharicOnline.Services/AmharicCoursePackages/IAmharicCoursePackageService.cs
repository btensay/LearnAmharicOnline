﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicCoursePackages
{
    /// <summary>
    /// Amharic Course Packages service interface
    /// </summary>
    public partial interface IAmharicCoursePackageService
    {
        /// <summary>
        /// Inserts an Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackage">Amharic Course Package</param>
        void InsertAmharicCoursePackage(AmharicCoursePackage amharicCoursePackage);

        /// <summary>
        /// Updates the Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackage">Amharic Course Package</param>
        void UpdateAmharicCoursePackage(AmharicCoursePackage amharicCoursePackage);

        /// <summary>
        /// Deletes an Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackage">Amharic Course Package</param>
        void DeleteAmharicCoursePackage(AmharicCoursePackage amharicCoursePackage);

        /// <summary>
        /// Gets an Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackageId">Amharic Course Package identifier</param>
        /// <returns>Amharic Course Package</returns>
        AmharicCoursePackage GetAmharicCoursePackageById(int amharicCoursePackageId);

        /// <summary>
        /// Gets all Amharic Course Packages
        /// </summary>
        /// <returns>Amharic Course Packages</returns>
        IList<AmharicCoursePackage> GetAllAmharicCoursePackages();
    }
}
