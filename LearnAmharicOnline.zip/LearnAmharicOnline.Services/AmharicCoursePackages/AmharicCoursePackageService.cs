﻿using LearnAmharicOnline.Core;
using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Services.AmharicCoursePackages
{
    public partial class AmharicCoursePackageService : IAmharicCoursePackageService
    {
        #region Fields
        private readonly IRepository<AmharicCoursePackage> _amharicCoursePackageRepository;
        #endregion

        #region Ctor

        public AmharicCoursePackageService(IRepository<AmharicCoursePackage> amharicCoursePackageRepository)
        {
            this._amharicCoursePackageRepository = amharicCoursePackageRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackage">Amharic Course Package</param>
        public virtual void InsertAmharicCoursePackage(AmharicCoursePackage amharicCoursePackage)
        {
            if(amharicCoursePackage == null)
            {
                throw new ArgumentNullException("amharicCoursePackage");
            }

            _amharicCoursePackageRepository.Insert(amharicCoursePackage);

            //event notification
            //_eventPublisher.EntityInserted(blogPost);
        }

        /// <summary>
        /// Updates the Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackage">Amharic Course Package</param>
        public virtual void UpdateAmharicCoursePackage(AmharicCoursePackage amharicCoursePackage)
        {
            _amharicCoursePackageRepository.Update(amharicCoursePackage);
        }

        /// <summary>
        /// Deletes an Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackage">Amharic Course Package</param>
        public virtual void DeleteAmharicCoursePackage(AmharicCoursePackage amharicCoursePackage)
        {

        }

        /// <summary>
        /// Gets an Amharic Course Package
        /// </summary>
        /// <param name="amharicCoursePackageId">Amharic Course Package identifier</param>
        /// <returns>Amharic Course Package</returns>
        public virtual AmharicCoursePackage GetAmharicCoursePackageById(int amharicCoursePackageId)
        {
            return _amharicCoursePackageRepository.GetById(amharicCoursePackageId);
        }

        public virtual IList<AmharicCoursePackage> GetAllAmharicCoursePackages()
        {
            return _amharicCoursePackageRepository.GetAll().ToList();
        }
    }
}
