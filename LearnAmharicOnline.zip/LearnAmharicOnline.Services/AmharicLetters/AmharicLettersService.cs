﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicLetters
{
    public partial class AmharicLettersService : IAmharicLettersService
    {
        #region Fields
        private readonly IRepository<AmharicLetter> _amharicLetterRepository;
        #endregion

        #region Ctor
        public AmharicLettersService(IRepository<AmharicLetter> amharicLetterRepository)
        {
            _amharicLetterRepository = amharicLetterRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an  Amharic Letter
        /// </summary>
        /// <param name="AmharicLetter"> Amharic Letter</param>
        public virtual void InsertAmharicLetter(AmharicLetter amharicLetter)
        {
            if(amharicLetter == null)
            {
                throw new ArgumentNullException("AmharicLetter");
            }

            _amharicLetterRepository.Insert(amharicLetter);
        }

        /// <summary>
        /// Updates the  Amharic Letter
        /// </summary>
        /// <param name="AmharicLetter">Amharic Letter</param>
        public virtual void UpdateAmharicLetter(AmharicLetter amharicLetter)
        {
            _amharicLetterRepository.Update(amharicLetter);
        }

        /// <summary>
        /// Deletes an  Amharic Letter
        /// </summary>
        /// <param name="AmharicCourseModule"> Amharic Letter</param>
        public virtual void DeleteAmharicLetter(AmharicLetter amharicLetter)
        {

        }

        /// <summary>
        /// Gets an  Amharic Letter
        /// </summary>
        /// <param name="amharicLetterId"> Amharic Letter identifier</param>
        /// <returns> Amharic Letter</returns>
        public virtual AmharicLetter GetAmharicLetterById(int amharicLetterId)
        {
            return _amharicLetterRepository.GetById(amharicLetterId);
        }

        public virtual IList<AmharicLetter> GetAllAmharicLetters()
        {
            return _amharicLetterRepository.GetAll().ToList();
        }

        /// <summary>
        /// Gets Amharic Letters Table with out tracking
        /// </summary>
        /// <returns>Amharic Letters Table</returns>
        public virtual IList<AmharicLetter> GetAmharicLettersTable()
        {
            return _amharicLetterRepository.TableNoTracking.ToList();
        }


        /// <summary>
        /// Checks if an Amharic Letter exists using an Amharic letter English reading
        /// </summary>
        /// <returns>Amharic letter English reading</returns>
        public virtual bool CheckIfAmharicLetterExists(string amharicLetterEnglishReading)
        {
            bool doesWordExist = false;

            var currentAmharicLetter = this.GetAllAmharicLetters()
                                           .Where(l => l.EnglishReading.Equals(amharicLetterEnglishReading))
                                           .ToList();

            if(currentAmharicLetter != null && currentAmharicLetter.Count > 0)
            {
                doesWordExist = true;
            }

            return doesWordExist;
        }
    }
}
