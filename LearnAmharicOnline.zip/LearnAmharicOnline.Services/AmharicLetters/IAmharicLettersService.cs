﻿using LearnAmharicOnline.Core.Domain;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicLetters
{
    /// <summary>
    ///  Amharic Letters service interface
    /// </summary>
    public partial interface IAmharicLettersService
    {
        /// <summary>
        /// Inserts an  Amharic Letter
        /// </summary>
        /// <param name="AmharicLetter">Amharic Letter</param>
        void InsertAmharicLetter(AmharicLetter amharicLetter);

        /// <summary>
        /// Updates the  Amharic Letter
        /// </summary>
        /// <param name="AmharicLetter">Amharic Letter</param>
        void UpdateAmharicLetter( AmharicLetter  AmharicLetter);

        /// <summary>
        /// Deletes an  Amharic Letter
        /// </summary>
        /// <param name="AmharicLetter"> Amharic Letter</param>
        void DeleteAmharicLetter( AmharicLetter  AmharicLetter);

        /// <summary>
        /// Gets an  Amharic Letter
        /// </summary>
        /// <param name="AmharicLetterId"> Amharic Letter identifier</param>
        /// <returns> Amharic Letter</returns>
         AmharicLetter GetAmharicLetterById(int amharicLetterId);

        /// <summary>
        /// Gets all  Amharic Letters
        /// </summary>
        /// <returns> Amharic Letters</returns>
        IList<AmharicLetter> GetAllAmharicLetters();

        /// <summary>
        /// Gets Amharic Letters Table with out tracking
        /// </summary>
        /// <returns>Amharic Letters Table</returns>
        IList<AmharicLetter> GetAmharicLettersTable();

        /// <summary>
        /// Checks if an Amharic Letter exists using an Amharic letter English reading
        /// </summary>
        /// <returns>Amharic letter English reading</returns>
        bool CheckIfAmharicLetterExists(string amharicLetterEnglishReading);
    }
}
