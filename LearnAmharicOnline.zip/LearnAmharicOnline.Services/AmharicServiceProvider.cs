﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Services.AmharicCourseModules;
using LearnAmharicOnline.Services.AmharicCoursePackages;
using LearnAmharicOnline.Services.AmharicExamResource;
using LearnAmharicOnline.Services.AmharicLearningResource;
using LearnAmharicOnline.Services.AmharicLetters;
using LearnAmharicOnline.Services.AmharicPracticeResource;
using LearnAmharicOnline.Services.AmharicWords;
using LearnAmharicOnline.Services.Customers;
using LearnAmharicOnline.Services.Subscriptions;
using System.Data.Entity;

namespace LearnAmharicOnline.Services
{
    public partial class AmharicServiceProvider : IAmharicServiceProvider
    {
        private IUnitOfWork _unitOfWork;
        private IAmharicLetterLearningService _amharicLetterLearningService;
        private IAmharicLettersService _amharicLettersService;
        private IAmharicWordsService _amharicWordsService;
        private IAmharicLetterExamService _amharicLetterExamService;

        private IAmharicPracticeFlashCardService _amharicPracticeFlashCardService;
        private IFlashCardLetterService _flashCardLetterService;
        private ILetterMemoryGameModuleService _letterMemoryGameModuleService;

        private IExamSectionService _examSectionService;
        private IExamQuestionService _examQuestionService;

        private IAmharicCoursePackageService _amharicCoursePackageService;
        private IAmharicCourseModuleService _amharicCourseModuleService;
        private ICourseSubscriptionsService _courseSubscriptionsService;
        private ICustomerService _customerService;

        public AmharicServiceProvider(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public ICustomerService CustomerService
        {
            get
            {
                if (_customerService == null)
                {
                    CustomerService = new CustomerService(_unitOfWork.CustomerRepo);
                }
                return _customerService;
            }
            private set
            {
                _customerService = value;
            }
        }

        public IAmharicLetterLearningService AmharicLetterLearningService
        {
            get
            {
                if (_amharicLetterLearningService == null)
                {
    AmharicLetterLearningService = new AmharicLetterLearningService(_unitOfWork.LetterLearningModuleRepository);
                }
                    return _amharicLetterLearningService;
            }
            private set
            {
                _amharicLetterLearningService = value;
            }
        }

        public IAmharicLettersService AmharicLettersService
        {
            get
            {
                if (_amharicLettersService == null)
                {
                  AmharicLettersService = new AmharicLettersService(_unitOfWork.AmharicLetterRepository);
                }

                return _amharicLettersService;
            }
            private set
            {
                _amharicLettersService = value;
            }
        }

        public IAmharicWordsService AmharicWordsService
        {
            get
            {
                if (_amharicWordsService == null)
                {
                    AmharicWordsService = new AmharicWordsService(_unitOfWork.AmharicWordRepository);
                }

                return _amharicWordsService;
            }
            private set
            {
                _amharicWordsService = value;
            }
        }

        public IAmharicLetterExamService AmharicLetterExamService
        {
            get
            {
                if (_amharicLetterExamService == null)
                {
                    AmharicLetterExamService = new AmharicLetterExamService(_unitOfWork.AmharicLetterExamRepo);
                }
                return _amharicLetterExamService;
            }
            set
            {
                _amharicLetterExamService = value;
            }
        }

        public IAmharicPracticeFlashCardService AmharicPracticeFlashCardService
        {
            get
            {
                if (_amharicPracticeFlashCardService == null)
                {
                    AmharicPracticeFlashCardService = new AmharicPracticeFlashCardService(_unitOfWork.LetterPracticeFlashcardRepo);
                }
                return _amharicPracticeFlashCardService;
            }
            set
            {
                _amharicPracticeFlashCardService = value;
            }
        }

        public IFlashCardLetterService FlashCardLetterService
        {
            get
            {
                if (_flashCardLetterService == null)
                {
                    FlashCardLetterService = new FlashCardLetterService(_unitOfWork.FlashCardLetterRepo);
                }
                return _flashCardLetterService;
            }
            set
            {
                _flashCardLetterService = value;
            }
        }

        public ILetterMemoryGameModuleService LetterMemoryGameModuleService
        {
            get
            {
                if (_letterMemoryGameModuleService == null)
                {
                    LetterMemoryGameModuleService = new LetterMemoryGameModuleService(_unitOfWork.LetterMemoryGameModuleRepo);
                }
                return _letterMemoryGameModuleService;
            }
            set
            {
                _letterMemoryGameModuleService = value;
            }
        }

        public IExamSectionService ExamSectionService
        {
            get
            {
                if (_examSectionService == null)
                {
                    ExamSectionService = new ExamSectionService(_unitOfWork.ExamSectionRepo);
                }
                return _examSectionService;
            }
            set
            {
                _examSectionService = value;
            }
        }

        public IExamQuestionService ExamQuestionService
        {
            get
            {
                if (_examQuestionService == null)
                {
                    ExamQuestionService = new ExamQuestionService(_unitOfWork.ExamQuestionRepo);
                }
                return _examQuestionService;
            }
            set
            {
                _examQuestionService = value;
            }
        }

        public IAmharicCoursePackageService AmharicCoursePackageService
        {
            get
            {
                if (_amharicCoursePackageService == null)
                {
                    AmharicCoursePackageService = new AmharicCoursePackageService(_unitOfWork.AmharicCoursePackageRepo);
                }
                return _amharicCoursePackageService;
            }
            set
            {
                _amharicCoursePackageService = value;
            }
        }

        public IAmharicCourseModuleService AmharicCourseModuleService
        {
            get
            {
                if (_amharicCourseModuleService == null)
                {
                    AmharicCourseModuleService = new AmharicCourseModuleService(_unitOfWork.AmharicCourseModuleRepo);
                }
                return _amharicCourseModuleService;
            }
            set
            {
                _amharicCourseModuleService = value;
            }
        }

        public ICourseSubscriptionsService CourseSubscriptionsService
        {
            get
            {
                if (_courseSubscriptionsService == null)
                {
                    CourseSubscriptionsService = new CourseSubscriptionsService(_unitOfWork.CourseSubscriptionRepo);
                }
                return _courseSubscriptionsService;
            }
            set
            {
                _courseSubscriptionsService = value;
            }
        }

    }
}
