﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicLearningResource
{
    public partial class AmharicLetterLearningService : IAmharicLetterLearningService
    {
        #region Fields
        private readonly IRepository<LetterLearningModule> _letterLearningModuleRepository;
        #endregion

        #region Ctor

        public AmharicLetterLearningService(IRepository<LetterLearningModule> letterLearningModuleRepository)
        {
            _letterLearningModuleRepository = letterLearningModuleRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Letter Learning Module Learning Module
        /// </summary>
        /// <param name="letterLearningModule">Letter Learning Module Learning Module</param>
        public virtual void InsertLetterLearningModule(LetterLearningModule letterLearningModule)
        {
            if(letterLearningModule == null)
            {
                throw new ArgumentNullException("letter Learning Module");
            }

            _letterLearningModuleRepository.Insert(letterLearningModule);
        }

        /// <summary>
        /// Updates the  Letter Learning Module
        /// </summary>
        /// <param name="LetterLearningModule">Letter Learning Module</param>
        public virtual void UpdateLetterLearningModule(LetterLearningModule letterLearningModule)
        {
            _letterLearningModuleRepository.Update(letterLearningModule);
        }

        /// <summary>
        /// Deletes an  Letter Learning Module
        /// </summary>
        /// <param name="AmharicCourseModule"> Letter Learning Module</param>
        public virtual void DeleteLetterLearningModule(LetterLearningModule letterLearningModule)
        {
            _letterLearningModuleRepository.Delete(letterLearningModule);
        }

        /// <summary>
        /// Gets an  Letter Learning Module
        /// </summary>
        /// <param name="letterLearningModuleId"> Letter Learning Module identifier</param>
        /// <returns> Letter Learning Module</returns>
        public virtual LetterLearningModule GetLetterLearningModuleById(int letterLearningModuleId)
        {
            return _letterLearningModuleRepository.GetById(letterLearningModuleId);
        }

        public virtual IList<LetterLearningModule> GetAllLetterLearningModules()
        {
            return _letterLearningModuleRepository.GetAll().ToList();
        }

    }
}
