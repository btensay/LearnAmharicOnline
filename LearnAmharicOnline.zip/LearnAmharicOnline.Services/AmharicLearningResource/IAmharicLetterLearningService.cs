﻿using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicLearningResource
{
    /// <summary>
    ///  Amharic Letter Learning Module service interface
    /// </summary>
    public partial interface IAmharicLetterLearningService
    {
        /// <summary>
        /// Inserts an Amharic Letter Learning Module
        /// </summary>
        /// <param name="letterLearningModule">Amharic Letter Learning Module</param>
        void InsertLetterLearningModule(LetterLearningModule letterLearningModule);

        /// <summary>
        /// Updates the Amharic Letter Learning Module
        /// </summary>
        /// <param name="letterLearningModule">Amharic Letter Learning Module</param>
        void UpdateLetterLearningModule(LetterLearningModule letterLearningModule);

        /// <summary>
        /// Deletes an  Amharic Letter Learning Module
        /// </summary>
        /// <param name="letterLearningModule">Amharic Letter Learning Module</param>
        void DeleteLetterLearningModule(LetterLearningModule letterLearningModule);

        /// <summary>
        /// Gets a Letter Learning Module
        /// </summary>
        /// <param name="letterLearningModuleId">Letter Learning Module identifier</param>
        /// <returns>Amharic Letter Learning Modules</returns>
        LetterLearningModule GetLetterLearningModuleById(int letterLearningModuleId);

        /// <summary>
        /// Gets all  Amharic Letter Learning Modules
        /// </summary>
        /// <returns> Amharic Letter Learning Modules</returns>
        IList<LetterLearningModule> GetAllLetterLearningModules();

    }
}
