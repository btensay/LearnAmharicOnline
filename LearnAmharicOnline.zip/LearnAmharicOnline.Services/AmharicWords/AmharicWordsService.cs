﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicWords
{
    public partial class AmharicWordsService : IAmharicWordsService
    {
        #region Fields
        private readonly IRepository<AmharicWord> _AmharicWordRepository;
        #endregion

        #region Ctor

        public AmharicWordsService(IRepository<AmharicWord> AmharicWordRepository)
        {
            _AmharicWordRepository = AmharicWordRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an  Amharic Letter
        /// </summary>
        /// <param name="AmharicWord"> Amharic Letter</param>
        public virtual void InsertAmharicWord(AmharicWord AmharicWord)
        {
            if(AmharicWord == null)
            {
                throw new ArgumentNullException("AmharicWord");
            }

            _AmharicWordRepository.Insert(AmharicWord);
        }

        /// <summary>
        /// Updates the  Amharic Letter
        /// </summary>
        /// <param name="AmharicWord">Amharic Letter</param>
        public virtual void UpdateAmharicWord(AmharicWord AmharicWord)
        {
            _AmharicWordRepository.Update(AmharicWord);
        }

        /// <summary>
        /// Deletes an  Amharic Letter
        /// </summary>
        /// <param name="AmharicCourseModule"> Amharic Letter</param>
        public virtual void DeleteAmharicWord(AmharicWord AmharicWord)
        {

        }

        /// <summary>
        /// Gets an  Amharic Letter
        /// </summary>
        /// <param name="AmharicWordId"> Amharic Letter identifier</param>
        /// <returns> Amharic Letter</returns>
        public virtual AmharicWord GetAmharicWordById(int AmharicWordId)
        {
            return _AmharicWordRepository.GetById(AmharicWordId);
        }

        public virtual IList<AmharicWord> GetAllAmharicWords()
        {
            return _AmharicWordRepository.GetAll().ToList();
        }

        /// <summary>
        /// Gets Amharic Words Table with out tracking
        /// </summary>
        /// <returns>Amharic Words Table</returns>
        public virtual IList<AmharicWord> GetAmharicWordsTable()
        {
            return _AmharicWordRepository.TableNoTracking.ToList();
        }
    }
}
