﻿using LearnAmharicOnline.Core.Domain;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicWords
{
    /// <summary>
    ///  Amharic Words service interface
    /// </summary>
    public partial interface IAmharicWordsService
    {
        /// <summary>
        /// Inserts an Amharic Word
        /// </summary>
        /// <param name="amharicWord">Amharic Word</param>
        void InsertAmharicWord(AmharicWord amharicWord);

        /// <summary>
        /// Updates the  Amharic Word
        /// </summary>
        /// <param name="amharicWord">Amharic Word</param>
        void UpdateAmharicWord(AmharicWord amharicWord);

        /// <summary>
        /// Deletes an  Amharic Word
        /// </summary>
        /// <param name=" AmharicWord"> Amharic Word</param>
        void DeleteAmharicWord(AmharicWord  AmharicWord);

        /// <summary>
        /// Gets an  Amharic Word
        /// </summary>
        /// <param name="amharicWordId"> Amharic Word identifier</param>
        /// <returns> Amharic Word</returns>
        AmharicWord GetAmharicWordById(int amharicWordId);

        /// <summary>
        /// Gets all  Amharic Words
        /// </summary>
        /// <returns> Amharic Words</returns>
        IList<AmharicWord> GetAllAmharicWords();

    }
}
