﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Membership;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.Subscriptions
{
    public partial class CourseSubscriptionsService : ICourseSubscriptionsService
    {
        #region Fields
        private readonly IRepository<CourseSubscription> _courseSubscriptionRepository;
        #endregion

        #region Ctor
        public CourseSubscriptionsService(IRepository<CourseSubscription> courseSubscriptionRepository)
        {
            this._courseSubscriptionRepository = courseSubscriptionRepository;
        }
        #endregion

        /// <summary>
        /// Inserts an Course Subscription
        /// </summary>
        /// <param name="courseSubscription">Course Subscription</param>
        public virtual void InsertCourseSubscription(CourseSubscription courseSubscription)
        {
            if(courseSubscription == null)
            {
                throw new ArgumentNullException("courseSubscription");
            }

            _courseSubscriptionRepository.Insert(courseSubscription);
        }

        /// <summary>
        /// Updates the Course Subscription
        /// </summary>
        /// <param name="courseSubscription">Course Subscription</param>
        public virtual void UpdateCourseSubscription(CourseSubscription courseSubscription)
        {
            _courseSubscriptionRepository.Update(courseSubscription);
        }

        /// <summary>
        /// Deletes an Course Subscription
        /// </summary>
        /// <param name="courseSubscription">Course Subscription</param>
        public virtual void DeleteCourseSubscription(CourseSubscription courseSubscription)
        {

        }

        /// <summary>
        /// Gets an Course Subscription
        /// </summary>
        /// <param name="courseSubscriptionId">Course Subscription identifier</param>
        /// <returns>Course Subscription</returns>
        public virtual CourseSubscription GetCourseSubscriptionById(int courseSubscriptionId)
        {
            return _courseSubscriptionRepository.GetById(courseSubscriptionId);
        }

        public virtual IList<CourseSubscription> GetAllCourseSubscriptions()
        {
            return _courseSubscriptionRepository.GetAll().ToList();
        }
    }
}
