﻿using LearnAmharicOnline.Core.Membership;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.Subscriptions
{
    /// <summary>
    /// Course Subscriptions service interface
    /// </summary>
    public partial interface ICourseSubscriptionsService
    {
        /// <summary>
        /// Inserts an Course Subscription
        /// </summary>
        /// <param name="courseSubscription">Course Subscription</param>
        void InsertCourseSubscription(CourseSubscription courseSubscription);

        /// <summary>
        /// Updates the Course Subscription
        /// </summary>
        /// <param name="courseSubscription">Course Subscription</param>
        void UpdateCourseSubscription(CourseSubscription courseSubscription);

        /// <summary>
        /// Deletes an Course Subscription
        /// </summary>
        /// <param name="courseSubscription">Course Subscription</param>
        void DeleteCourseSubscription(CourseSubscription courseSubscription);

        /// <summary>
        /// Gets an Course Subscription
        /// </summary>
        /// <param name="courseSubscriptionId">Course Subscription identifier</param>
        /// <returns>Course Subscription</returns>
        CourseSubscription GetCourseSubscriptionById(int courseSubscriptionId);

        /// <summary>
        /// Gets all Course Subscriptions
        /// </summary>
        /// <returns>Course Subscriptions</returns>
        IList<CourseSubscription> GetAllCourseSubscriptions();
    }
}
