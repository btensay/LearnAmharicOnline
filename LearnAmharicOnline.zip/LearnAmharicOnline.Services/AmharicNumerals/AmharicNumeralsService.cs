﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.AmharicNumerals
{
    public partial class AmharicNumeralsService : IAmharicNumeralsService
    {
        #region Fields
        private readonly IRepository<AmharicNumeral> _amharicNumeralRepository;
        #endregion

        #region Ctor

        public AmharicNumeralsService(IRepository<AmharicNumeral> AmharicNumeralRepository)
        {
            this._amharicNumeralRepository = AmharicNumeralRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeral"> Amharic Numeral</param>
        public virtual void InsertAmharicNumeral(AmharicNumeral amharicNumeral)
        {
            if(amharicNumeral == null)
            {
                throw new ArgumentNullException("AmharicNumeral");
            }

            _amharicNumeralRepository.Insert(amharicNumeral);
        }

        /// <summary>
        /// Updates the  Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeral">Amharic Numeral</param>
        public virtual void UpdateAmharicNumeral(AmharicNumeral amharicNumeral)
        {
            _amharicNumeralRepository.Update(amharicNumeral);
            _amharicNumeralRepository.SaveChanges();
        }

        /// <summary>
        /// Deletes an  Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeral"> Amharic Numeral</param>
        public virtual void DeleteAmharicNumeral(AmharicNumeral amharicNumeral)
        {

        }

        /// <summary>
        /// Gets an  Amharic Numeral
        /// </summary>
        /// <param name="AmharicNumeralId"> Amharic Numeral identifier</param>
        /// <returns> Amharic Numeral</returns>
        public virtual AmharicNumeral GetAmharicNumeralById(int amharicNumeralId)
        {
            return _amharicNumeralRepository.GetById(amharicNumeralId);
        }

        public virtual IList<AmharicNumeral> GetAllAmharicNumerals()
        {
            return _amharicNumeralRepository.GetAll().ToList();
        }
    }
}
