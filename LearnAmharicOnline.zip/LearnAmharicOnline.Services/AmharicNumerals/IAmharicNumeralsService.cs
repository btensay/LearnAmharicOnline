﻿using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.AmharicNumerals
{
    /// <summary>
    ///  Amharic Numerals service interface
    /// </summary>
    public partial interface IAmharicNumeralsService
    {
        /// <summary>
        /// Inserts an  Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeral">Amharic Numeral</param>
        void InsertAmharicNumeral(AmharicNumeral amharicNumeral);

        /// <summary>
        /// Updates the  Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeral">Amharic Numeral</param>
        void UpdateAmharicNumeral( AmharicNumeral  amharicNumeral);

        /// <summary>
        /// Deletes an  Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeral"> Amharic Numeral</param>
        void DeleteAmharicNumeral( AmharicNumeral amharicNumeral);

        /// <summary>
        /// Gets an  Amharic Numeral
        /// </summary>
        /// <param name="amharicNumeralId"> Amharic Numeral identifier</param>
        /// <returns> Amharic Numeral</returns>
        AmharicNumeral GetAmharicNumeralById(int amharicNumeralId);

        /// <summary>
        /// Gets all  Amharic Numerals
        /// </summary>
        /// <returns> Amharic Numerals</returns>
        IList<AmharicNumeral> GetAllAmharicNumerals();
    }
}
