﻿using LearnAmharicOnline.Core.Membership;
using System.Collections.Generic;

namespace LearnAmharicOnline.Services.Customers
{
    /// <summary>
    /// Customer service interface
    /// </summary>
    public partial interface ICustomerService
    {
            /// <summary>
            /// Inserts an Customer
            /// </summary>
            /// <param name="Customer">Customer</param>
            void InsertCustomer(Customer customer);

            /// <summary>
            /// Updates the Customer
            /// </summary>
            /// <param name="Customer">Customer</param>
            void UpdateCustomer(Customer Customer);

            /// <summary>
            /// Deletes an Customer
            /// </summary>
            /// <param name="Customer">Customer</param>
            void DeleteCustomer(Customer Customer);

            /// <summary>
            /// Gets an Customer
            /// </summary>
            /// <param name="CustomerId">Customer identifier</param>
            /// <returns>Customer</returns>
            Customer GetCustomerById(int customerId);

            /// <summary>
            /// Gets all Customer
            /// </summary>
            /// <returns>Customer</returns>
            IList<Customer> GetAllCustomers();

            /// <summary>
            /// GetsCustomer Table with out tracking
            /// </summary>
            /// <returns>Customers Table</returns>
            IList<Customer> GetCustomersTable();
    }
}
