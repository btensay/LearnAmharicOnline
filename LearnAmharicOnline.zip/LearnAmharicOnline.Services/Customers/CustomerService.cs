﻿using LearnAmharicOnline.Core.Data;
using LearnAmharicOnline.Core.Membership;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LearnAmharicOnline.Services.Customers
{
    public partial class CustomerService : ICustomerService
    {
        #region Fields
        private readonly IRepository<Customer> _customerRepository;
        #endregion

        #region Ctor
        public CustomerService(IRepository<Customer> customerRepository)
        {
            _customerRepository = customerRepository;
        }

        #endregion

        /// <summary>
        /// Inserts an  Customer
        /// </summary>
        /// <param name="Customer"> Customer</param>
        public virtual void InsertCustomer(Customer customer)
        {
            if (customer == null)
            {
                throw new ArgumentNullException("Customer");
            }

            _customerRepository.Insert(customer);
        }

        /// <summary>
        /// Updates the  Customer
        /// </summary>
        /// <param name="Customer">Customer</param>
        public virtual void UpdateCustomer(Customer customer)
        {
            _customerRepository.Update(customer);
        }

        /// <summary>
        /// Deletes an  Customer
        /// </summary>
        /// <param name="AmharicCourseModule"> Customer</param>
        public virtual void DeleteCustomer(Customer customer)
        {

        }

        /// <summary>
        /// Gets an  Customer
        /// </summary>
        /// <param name="customerId"> Customer identifier</param>
        /// <returns> Customer</returns>
        public virtual Customer GetCustomerById(int customerId)
        {
            return _customerRepository.GetById(customerId);
        }

        public virtual IList<Customer> GetAllCustomers()
        {
            return _customerRepository.GetAll().ToList();
        }

        /// <summary>
        /// Gets Customers Table with out tracking
        /// </summary>
        /// <returns>Customers Table</returns>
        public virtual IList<Customer> GetCustomersTable()
        {
            return _customerRepository.TableNoTracking.ToList();
        }

    }
}
