﻿using LearnAmharicOnline.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Services
{
    public partial class LAOService<T>
    {
        private ILAOServiceProvider<T> _serviceProvider;

        public LAOService()
        {
            _serviceProvider = new LAOServiceProvider();
        }

    }
}
