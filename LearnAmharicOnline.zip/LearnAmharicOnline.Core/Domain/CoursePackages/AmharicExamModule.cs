﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public class AmharicExamModule : BaseEntity
    {
        public void AmharicSKillAssessment() { } //letter, word, comprehensions, composition, etc skills assessemnt
    }
}
