﻿using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public class LetterCourseModule : CourseModuleComponent
    {
        protected LetterLearningModule letterLearningModule { get; set;}
        protected LetterPracticeModule letterPracticeModule { get; set; }
        protected LetterExamModule letterExamModule { get; set; }

        public LetterCourseModule()
        {
        }

        public override void SetLearningModule()
        {
            //learning module for Amharic letter
            this.letterLearningModule = new LetterLearningModule();
        }

        public override void SetPracticeModule()
        {
            //Practice module for Amharic letter
            this.letterPracticeModule = new LetterPracticeModule();
        }

        public override void SetExamModule()
        {
            //Exam module for Amharic letter
            this.letterExamModule = new LetterExamModule();
        }

    }
}
