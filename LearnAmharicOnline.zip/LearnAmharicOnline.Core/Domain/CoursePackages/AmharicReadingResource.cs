﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public class LearningReadingResource : BaseEntity
    {
        public LearningReadingResource()
        {
            AmharicLetters = new List<AmharicLetter>();
        }

        public string Title { get; set; }
        public IList<AmharicLetter> AmharicLetters { get; set; }
    }

}
