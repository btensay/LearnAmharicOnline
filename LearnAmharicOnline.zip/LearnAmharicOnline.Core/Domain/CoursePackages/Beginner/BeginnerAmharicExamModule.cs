﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Beginner
{
    public class BeginnerAmharicExamModule : AmharicExamModule
    {
       // public void AmharicSKillAssessment() { }  //letter, word, comprehensions, composition, etc skills assessemnt
    }
}
