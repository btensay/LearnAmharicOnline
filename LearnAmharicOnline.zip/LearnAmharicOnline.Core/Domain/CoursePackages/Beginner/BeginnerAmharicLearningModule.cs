﻿namespace LearnAmharicOnline.Core.Domain.CoursePackages.Beginner
{
    public class BeginnerAmharicLearningModule : LetterLearningModule
    {
        private LearningReadingResource AmharicBeginnerReadingResource;
        private LearningWrittingResource AmharicBeginnerWrittingResource;

        public BeginnerAmharicLearningModule()
        {
        }
        /*
        public BeginnerAmharicLearningModule([Dependency("BeginnerReadingResource")] LearningReadingResource beginnerReadingResource,
                                             [Dependency("BeginnerWrittingResource")] LearningWrittingResource beginnerWrittingResource)
        {
            AmharicBeginnerReadingResource = beginnerReadingResource;
            AmharicBeginnerWrittingResource = beginnerWrittingResource;
        }*/

        public LearningReadingResource ReadingModule
        {
            // reading Amharic letters - read out Amharic letters table with symbol, audio, sample word and image
            // to be implmented:  populate the AmharicLetters private member here
            get
            {
                return AmharicBeginnerReadingResource;
            }
        }

        public LearningWrittingResource WrittingModule
        {
            //  writting Amharic letters - writting guide for each Amharic letters
            get
            {
                return AmharicBeginnerWrittingResource;
            }
        }

        public void CompositionModule()
        {
            //  word formation using Amharic letters - sample word, image etc
        }

     }
}
