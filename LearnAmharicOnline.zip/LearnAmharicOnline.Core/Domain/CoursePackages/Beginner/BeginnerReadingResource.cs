﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Beginner
{
    public class BeginnerReadingResource : LearningReadingResource
    {

        public BeginnerReadingResource()
        {
        }

        //public int Id { get; set; }
       // public string Title { get; set; }
    }
}
