﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Beginner
{
    public class BeginnerAmharicFlashCardResource // : IAmharicPracticeModule
    {
        private IAmharicFlashCardResource BeginnerAmharicFlashCard;

        public BeginnerAmharicFlashCardResource()
        {

        }

        // flash card module
        public IAmharicFlashCardResource FlashCard
        {
            get { return BeginnerAmharicFlashCard; }
        }

        // memory game module
        public void MemoryGame() { }

        //  mock test module
        public void MockTest() { }
    }
}
