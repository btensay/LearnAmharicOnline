﻿using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Beginner
{
    public class BeginnerAmharicCourse : AmharicCoursePackage
    {
        public BeginnerAmharicCourse()
        {
            AmharicCourseModules = new List<AmharicCourseModule>();
        }

        public virtual IList<AmharicCourseModule> AmharicCourseModules { get; set; }
    }

}
