﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Intermediate
{
    public class AdvancedAmharicExamModule : AmharicExamModule
    {
       // public void AmharicSKillAssessment() { }  //letter, word, comprehensions, composition, etc skills assessemnt
    }
}
