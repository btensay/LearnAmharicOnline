﻿namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public abstract class CourseModuleComponent : BaseEntity
    {
        public abstract void SetLearningModule();
        public abstract void SetPracticeModule();
        public abstract void SetExamModule();
    }
}
