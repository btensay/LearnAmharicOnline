﻿using LearnAmharicOnline.Core.Domain.Core;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public class AmharicCourseModule : BaseEntity
    {
        public AmharicCourseModule() { }

        public virtual string Title { get; set; }
        public virtual string Description { get; set; }
        public virtual string Goal { get; set; }

        public virtual CourseModuleComponent CourseModuleComponent { get; set; }
        public AmharicCoursePackage ParentCoursePackage { get; set; }
    }
 }
