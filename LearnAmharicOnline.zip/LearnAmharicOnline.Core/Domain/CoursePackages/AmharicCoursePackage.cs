﻿using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public partial class AmharicCoursePackage : BaseEntity
    {
        public AmharicCoursePackage()
        {
            AmharicCourseModules = new List<AmharicCourseModule>();
        }

        public virtual string Title { get; set; }
        public virtual string Description { get; set; }

        //List of Amharic Course Modules
        public IList<AmharicCourseModule> AmharicCourseModules { get; set; }

        public void AddCourseModule(AmharicCourseModule moduleToAdd)
        {
            moduleToAdd.ParentCoursePackage = this;
            AmharicCourseModules.Add(moduleToAdd);
        }
    }
}
