﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public interface IAmharicCourseItem
    {
        //id
        //title

        //flashcard
        //game
        //mock exam
        //exam

        //status - pending, started, completed, etc
    }    
}
