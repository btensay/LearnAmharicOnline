﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Intermediate
{
    public class IntermediateAmharicPracticeModule //: PracticeModule
    {
       /* private IAmharicFlashCardResource IntermediateAmharicFlashCard;
        // flash card module
        //public void FlashCard() { }
        public IAmharicFlashCardResource FlashCard
        {
            get { return IntermediateAmharicFlashCard; }
        }

        // memory game module
        public void MemoryGame() { }

        //  mock test module
        public void MockTest() { }*/
    }
}
