﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Intermediate
{
    public class IntermediateReadingResource : LearningReadingResource
    {
        //private IList<IReadingResource> ReadingResources;

        public IntermediateReadingResource()
        {
           // ReadingResourceSet = new List<IReadingResource>();
        }

       /* public IList<AmharicWord> AmharicWords
        {
            get
            {
                return AmharicWordsList;
            }
        }*/

       // public int Id { get; set; }
        //public string Title { get; set; }
        //public IList<IReadingResource> ReadingResourceSet { get; set; }
    }
}
