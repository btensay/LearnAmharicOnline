﻿using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain.CoursePackages.Intermediate
{
    //[Table("IntermediateAmharicCourse")]
    public class IntermediateAmharicCourse //: AmharicCoursePackage
    {
        public IntermediateAmharicCourse()
        {
            AmharicWords = new List<AmharicWord>();
            AmharicShortStories = new List<AmharicShortStory>();
        }

        public IList<AmharicWord> AmharicWords { get; set; }
        public IList<AmharicShortStory> AmharicShortStories { get; set; }

    /*    private IList<IAmharicCourseItem> AmharicCourseItems;
        private IAmharicLearningModule AmharicLearningIntermediateModule;
        private IAmharicPracticeModule AmharicPracticeIntermediateModule;
        private IAmharicExamModule AmharicTestIntermediateModule;

        public AmharicIntermediateCourseModule([Dependency("IntermediateLearningModule")] IAmharicLearningModule IntermediateLearningModule,
                                                                                    [Dependency("IntermediatePracticeModule")] IAmharicPracticeModule IntermediatePracticeModule,
                                                                                    [Dependency("IntermediateExamModule")] IAmharicExamModule IntermediateExamModule)
        {
            AmharicLearningIntermediateModule = IntermediateLearningModule;
            AmharicPracticeIntermediateModule = IntermediatePracticeModule;
            AmharicTestIntermediateModule = IntermediateExamModule;

            AmharicCourseItems = new List<IAmharicCourseItem>();
        }

        public int Id { get; set; }

        public IAmharicLearningModule LetterLearningModule
        {
            get { return AmharicLearningIntermediateModule; }
        }

        public IAmharicPracticeModule PracticeModule
        {
            get { return AmharicPracticeIntermediateModule; }
        }

        public IAmharicExamModule ExamModule
        {
            get { return AmharicTestIntermediateModule; }
        }

        public IList<IAmharicCourseItem> CourseItems
        {
            get
            {
                return AmharicCourseItems;
            }
        }
        */

    }
}
