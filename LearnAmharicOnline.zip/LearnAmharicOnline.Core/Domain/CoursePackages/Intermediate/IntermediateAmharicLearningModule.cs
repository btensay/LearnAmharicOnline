﻿namespace LearnAmharicOnline.Core.Domain.CoursePackages.Intermediate
{
    public class IntermediateAmharicLearningModule : LetterLearningModule
    {
        //private LearningReadingResource IntermediateReadingResource;
        //private LearningWrittingResource IntermediateWrittingResource;

        public IntermediateAmharicLearningModule()
        {
        }

       // public IntermediateAmharicLearningModule([Dependency("IntermediateReadingResource")] LearningReadingResource intermediateReadingResource,
        //  [Dependency("IntermediateWrittingResource")] LearningWrittingResource intermediateWrittingResource)
       // {
            //IntermediateReadingResource = intermediateReadingResource;
           // IntermediateWrittingResource = intermediateWrittingResource;
       // }

      /*  public LearningReadingResource ReadingModule
        {
            // reading Amharic letters - read out Amharic letters table with symbol, audio, sample word and image
            // to be implmented:  populate the AmharicLetters private member here
            get
            {
                return IntermediateReadingResource;
            }
        }

        public LearningWrittingResource WrittingModule
        {
            //  writting Amharic letters - writting guide for each Amharic letters
            get
            {
                return IntermediateWrittingResource;
            }
        }*/

       /* public override void CompositionModule()
        {
           //  phrase/expressions formation using Amharic words - sample word, image etc
        }*/
    }
}
