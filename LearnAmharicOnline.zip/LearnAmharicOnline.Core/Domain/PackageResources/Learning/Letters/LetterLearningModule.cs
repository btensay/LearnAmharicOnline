﻿using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public class LetterLearningModule : BaseEntity
    {
        public LetterLearningModule()
        {
            AmharicLetters = new List<AmharicLetter>();
        }

        public string Title { get; set; }

        public IList<AmharicLetter> AmharicLetters { get; set; }

        public void AddRelatedAmharicLetter(AmharicLetter letter)
        {
            AmharicLetters.Add(letter);
        }

        public IList<AmharicLetter> GetModuleResources()
        {
            return AmharicLetters;
        }

        /*  Methods to implement
         *  -   letter reading learning resources
         *  -   letter writing learning resources
         *  -   letter composition learning resource ??
         */

        //Methods to be implemented
        //Get letter set by row index
        //Get letter set by columon index
        //Get letter set by English vowel name, i.e. a, e, i, o, u phonetics/

    }
}
