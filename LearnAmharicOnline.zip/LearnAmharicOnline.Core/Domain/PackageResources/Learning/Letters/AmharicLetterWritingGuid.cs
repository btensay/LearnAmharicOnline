﻿using LearnAmharicOnline.Core.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.Practice
{
    public class AmharicLetterWritingGuid : BaseEntity
    {
        public AmharicLetterWritingGuid()
        { }

        public ImageResource WritingGuidImageResource
        {
            get;
            set;
        }

        public IAudioResource WritingGuidAudioResource
        {
            get;
            set;
        }

    }
}
