﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters
{
    public class FlashCardLetter : BaseEntity
    {
        public FlashCardLetter() { }

        public virtual AmharicLetterFlashcard ParentFlashcard { get; set; }
        public AmharicLetter AmharicLetter { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string ThirdName { get; set; }
        public string FourthName { get; set; }
    }
}
