﻿using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain.CoursePackages
{
    public class AmharicLetterFlashcard : BaseEntity
    {
        public AmharicLetterFlashcard()
        {
            FlashCardLetters = new List<FlashCardLetter>();
        }

        public IList<FlashCardLetter> FlashCardLetters { get; set; }

        public void AddFlashCardLetter(FlashCardLetter flashCardLetter)
        {
            flashCardLetter.ParentFlashcard = this;
            FlashCardLetters.Add(flashCardLetter);
        }
    }
}
