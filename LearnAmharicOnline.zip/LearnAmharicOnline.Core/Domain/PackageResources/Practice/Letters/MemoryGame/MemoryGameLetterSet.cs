﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters
{
    public class MemoryGameLetterSet : BaseEntity
    {
        public MemoryGameLetterSet()
        {
            AmharicLetters = new List<AmharicLetter>();
            AmharicWords = new List<AmharicWord>();
        }

        public IList<AmharicLetter> AmharicLetters { get; set; }
        public IList<AmharicWord> AmharicWords { get; set; }
        public AmharicLetterMemoryGame ParentGameModule { get; set; }

        public bool IsEligible(AmharicWord wordToValidate)
        {
            bool isWordValid = true;

            var wordLetters = wordToValidate.AmharicText.ToList();

            foreach (var wordLetter in wordLetters)
            {
                var existingLetter = AmharicLetters.ToList().Where(l => l.AmharicSymbol.Equals(wordLetter));

                if (existingLetter == null || (existingLetter != null && existingLetter.Count() == 0))
                {
                    isWordValid = false;
                    break;
                }
            }

            return isWordValid;
        }
    }
}
