﻿using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters
{
    public class AmharicLetterMemoryGame : BaseEntity
    {
        public AmharicLetterMemoryGame()
        {
            MemoryGameLetterSets = new List<MemoryGameLetterSet>();
        }

        public GameType Type { get; set; }
        public IList<MemoryGameLetterSet> MemoryGameLetterSets { get; set; }

        public void AddMemoryGameLetterSet(MemoryGameLetterSet letterSet)
        {
            letterSet.ParentGameModule = this;
            MemoryGameLetterSets.Add(letterSet);
        }
    }
 }