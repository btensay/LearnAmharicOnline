﻿namespace LearnAmharicOnline.Core.Domain.Practice
{
    public class AmharicWordMemoryGame : BaseEntity
    {
    }
}
