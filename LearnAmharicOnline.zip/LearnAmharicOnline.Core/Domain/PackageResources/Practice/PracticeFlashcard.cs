﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Domain.Practice;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Practice
{
    public class PracticeFlashcard : BaseEntity
    {
        public PracticeFlashcard()
        { }

      public AmharicLetterFlashcard LetterPracticeFlashcard { get; set; }
      public AmharicWordFlashCard AmharicWordFlashCard { get; set; }

    }
}
