﻿using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using LearnAmharicOnline.Core.Domain.Practice;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Practice
{
    public class PracticeMemoryGame : BaseEntity
    {
        public PracticeMemoryGame(){}

        public AmharicLetterMemoryGame LetterMemoryGameModule { get; set; }
        public AmharicWordMemoryGame AmharicWordMemoryGame { get; set; }
    }
}
