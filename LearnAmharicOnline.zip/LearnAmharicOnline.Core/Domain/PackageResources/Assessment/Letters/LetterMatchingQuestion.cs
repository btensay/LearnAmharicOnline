﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterMatchingQuestion : MatchingQuestion
    {
        public LetterMatchingQuestion()
        { }

        public string AmharicLetterText { get; set; }
        public string EnglishReadingText { get; set; }

        //The LetterLearningModule this exam targets to assess
        public LetterLearningModule LetterLearningModule { get; set; }

        public LetterMatchingSection ParentLetterMatchingSection { get; set; }
    }
}
