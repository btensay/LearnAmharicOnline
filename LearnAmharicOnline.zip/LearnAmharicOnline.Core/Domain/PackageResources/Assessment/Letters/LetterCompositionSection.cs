﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterCompositionSection : CompositionSection
    {
        public LetterCompositionSection()
        {
            GlobalId = Guid.NewGuid();
            Name = "Letter Composition Section test";
            LetterCompositionQuestions = new List<LetterCompositionQuestion>();
        }

        public IList<LetterCompositionQuestion> LetterCompositionQuestions { get; set; }

        public LetterCompositionSection AddLetterCompositionQuestion(LetterCompositionQuestion questionToAdd)
        {
            questionToAdd.ParentLetterCompositionSection = this;
            this.LetterCompositionQuestions.Add(questionToAdd);
            return this;
        }
    }
}
