﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterMultipleChoiceQuestion : MultipleChoiceQuestion
    {
        public LetterMultipleChoiceQuestion() { }

        public string QuestionAmharicLetter { get; set; }
        public string FirstAnswerLetter { get; set; }
        public string SecondAnswerLetter { get; set; }
        public string ThirdAnswerLetter { get; set; }
        public string FourthAnswerLetter { get; set; }
        public string CorrectAnswerLetter { get; set; }
        public AmharicLetter CurrentAmharicLetter { get; set; }

        //The LetterLearningModule this exam targets to assess
        public LetterLearningModule LetterLearningModule { get; set; }

        public LetterMultipleChoiceSection ParentLetterMultipleChoiceSection { get; set; }
    }
}
