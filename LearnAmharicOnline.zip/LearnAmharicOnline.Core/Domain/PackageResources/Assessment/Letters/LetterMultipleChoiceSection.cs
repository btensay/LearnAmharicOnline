﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterMultipleChoiceSection : MultipleChoiceSection
    {
        public LetterMultipleChoiceSection()
        {
            GlobalId = Guid.NewGuid();
            Name = "Letter MultipleChoice Section test";
            LetterMultipleChoiceQuestions = new List<LetterMultipleChoiceQuestion>();
         }

        public IList<LetterMultipleChoiceQuestion> LetterMultipleChoiceQuestions { get; set; }

        public void AddLetterMultipleChoiceQuestion(LetterMultipleChoiceQuestion multipleChoiceQuestionToAdd)
        {
            multipleChoiceQuestionToAdd.ParentLetterMultipleChoiceSection = this;
            LetterMultipleChoiceQuestions.Add(multipleChoiceQuestionToAdd);
        }
    }
}
