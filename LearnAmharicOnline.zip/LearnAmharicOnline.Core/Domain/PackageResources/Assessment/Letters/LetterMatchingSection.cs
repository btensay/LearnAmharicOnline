﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterMatchingSection : MatchingSection
    {
        public LetterMatchingSection()
        {
            GlobalId = Guid.NewGuid();
            Name = "Letter Matching Section test";
            LetterMatchingQuestions = new List<LetterMatchingQuestion>();
        }

        public IList<LetterMatchingQuestion> LetterMatchingQuestions { get; set; }
    }
}
