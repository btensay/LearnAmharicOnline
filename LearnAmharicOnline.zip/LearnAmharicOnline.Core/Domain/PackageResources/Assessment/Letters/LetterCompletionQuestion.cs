﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterCompletionQuestion : CompletionQuestion
    {
        public LetterCompletionQuestion()
        { }

        public string WordFirstPart { get; set; }
        public string WordSecondPart { get; set; }
        public string WordMiddlePart { get; set; } // the question letter to choose from
        public AmharicWord AnswerWord { get; set; }

        // One of the following choices, being picked randomly,
        // will be the correct answer letter and equals to WordMiddlePart
        public string FirstChoiceLetter { get; set; }
        public string SecondChoiceLetter { get; set; }
        public string ThirdChoiceLetter { get; set; }
        public string FourthChoiceLetter { get; set; }

        //The LetterLearningModule this exam targets to assess
        public LetterLearningModule LetterLearningModule { get; set; }

        public LetterCompletionSection ParentLetterCompletionSection { get; set; }
    }
}
