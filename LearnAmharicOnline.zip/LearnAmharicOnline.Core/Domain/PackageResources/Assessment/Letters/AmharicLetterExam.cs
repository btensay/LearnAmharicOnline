﻿using LearnAmharicOnline.Core.Domain.Assessment;
using System;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class AmharicLetterExam : AmharicSkillsExam
    {
        public AmharicLetterExam()
        {
        }

        public override MultipleChoiceSection GetMultipleChoiceSection()
        {
            return MultipleChoiceSection;
        }

        public override MatchingSection GetMatchingSection()
        {
            return MatchingSection;
        }

        public override CompletionSection GetCompletionSection()
        {
            return CompletionSection;
        }

        public override CompositionSection GetCompositionSection()
        {
            return CompositionSection;
        }
    }

}
