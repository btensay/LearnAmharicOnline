﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterCompositionQuestion : CompositionQuestion
    {
        public LetterCompositionQuestion()
        {
            AmharicLettersPool = new List<AmharicLetter>();
            AmharicWords = new List<AmharicWord>();
        }

        public IList<AmharicLetter> AmharicLettersPool { get; set; }
        public IList<AmharicWord> AmharicWords { get; set; }
        public LetterCompositionSection ParentLetterCompositionSection { get; set; }

        //The LetterLearningModule this exam targets to assess
        public LetterLearningModule LetterLearningModule { get; set; }
    }
}
