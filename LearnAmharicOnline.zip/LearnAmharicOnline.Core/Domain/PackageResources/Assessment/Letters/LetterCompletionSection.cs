﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters
{
    public class LetterCompletionSection : CompletionSection
    {
        public LetterCompletionSection()
        {
            GlobalId = Guid.NewGuid();
            Name = "Letter Completion Section test";
            LetterCompletionQuestions = new List<LetterCompletionQuestion>();
        }

        public IList<LetterCompletionQuestion> LetterCompletionQuestions { get; set; }
    }
}
