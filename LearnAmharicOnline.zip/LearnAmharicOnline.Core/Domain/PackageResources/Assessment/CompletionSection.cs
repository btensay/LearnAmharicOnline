﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment
{
    public class CompletionSection : ExamSection
    {
        public IList<CompletionQuestion> CompletionQuestions { get; set; }
    }
}
