﻿namespace LearnAmharicOnline.Core.Domain.Assessment
{
    using PackageResources.Assessment;
    using System;

    public class AmharicSkillsExam : BaseEntity
    {
        public AmharicSkillsExam()
        {

        }

        public string Description { get; set; }
        public virtual CoursePackageLevelType PackageLevel { get; set; }
        public ExamType Type { get; set; }
        public virtual int MaximumScore { get; private set; } //to be set internally based on the number of questions in each exam sections
        public virtual int ActualScore { get; set; }
        public ExamStatusType ExamStatus { get; set; }
        public DateTime? ExamStartDate { get; set; }
        public DateTime? ExamEndDate { get; set; }

        public virtual MultipleChoiceSection MultipleChoiceSection { get; set; }
        public virtual MatchingSection MatchingSection { get; set; }
        public virtual CompletionSection CompletionSection { get; set; }
        public virtual CompositionSection CompositionSection { get; set; }

        public virtual MultipleChoiceSection GetMultipleChoiceSection()
        {
            return MultipleChoiceSection;
        }

        public virtual MatchingSection GetMatchingSection()
        {
            return MatchingSection;
        }

        public virtual CompletionSection GetCompletionSection()
        {
            return CompletionSection;
        }

        public virtual CompositionSection GetCompositionSection()
        {
            return CompositionSection;
        }
    }
}

