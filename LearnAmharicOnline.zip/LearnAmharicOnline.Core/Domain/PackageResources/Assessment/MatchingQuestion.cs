﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LearnAmharicOnline.Core.Domain.PackageResources.Assessment
{
    public class MatchingQuestion: ExamQuestion
    {
    }
}