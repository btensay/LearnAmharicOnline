﻿using LearnAmharicOnline.Core.Domain.PackageResources.Practice;

namespace LearnAmharicOnline.Core.Domain.Core
{
    public class PracticeModule : BaseEntity
    {

        public PracticeModule()
        {
        }

        public PracticeFlashcard PracticeFlashcard { get; set; }
        public PracticeMemoryGame MemoryGameModule { get; set; }

    }
}
