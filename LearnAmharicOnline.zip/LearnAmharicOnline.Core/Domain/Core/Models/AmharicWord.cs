﻿using LearnAmharicOnline.Core.Domain.Core;
using LearnAmharicOnline.Core.Domain.Core.Models;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Domain
{
    public class AmharicWord : BaseEntity
    {

        public AmharicWord()
        {
            RelatedLetters = new List<AmharicLetter>();
        }

        public string AudioUrl { get; set; }

        public string AmharicText { get; set; }

        public string EnglishWordReading { get; set; }

        public string EnglishTranslation { get; set; }

        public virtual ICollection<AmharicLetter> RelatedLetters { get; set; }

        public virtual ICollection<MemoryGameLetterSet> MemoryGameLetterSets { get; set; }

        public AmharicWordImage AmharicWordImage { get; set; }

        public void AddRelatedLetter(AmharicLetter letter)
        {
            RelatedLetters.Add(letter);
        }
    }
}
