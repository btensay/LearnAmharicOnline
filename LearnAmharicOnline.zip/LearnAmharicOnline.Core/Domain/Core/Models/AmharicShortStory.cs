﻿using LearnAmharicOnline.Core.Domain.Core;

namespace LearnAmharicOnline.Core.Domain
{
    public class AmharicShortStory : BaseEntity
    {
        public AmharicShortStory(){}

        public string AmharicTitle
        {
            get;
            set;
        }

        public string EnglishTitle
        {
            get;
            set;
        }

        public string AmharicText
        {
            get;
            set;
        }

        public string EnglishTranslation
        {
            get;
            set;
        }

        public string AudioUrl
        {
            get;
            set;
        }

        public string ImageUrl
        {
            get;
            set;
        }

        public void AmResource() { }

    }
}
