﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.Core.Models
{
    public class AmharicWordImage : BaseEntity
    {
        public string Description { get; set; }
        public string Url { get; set; }
    }
}
