﻿using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.Core;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using LearnAmharicOnline.Core.Domain.Practice;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LearnAmharicOnline.Core.Domain
{
    public class AmharicLetter: BaseEntity
    {
        public AmharicLetter()
        {
            ExampleWords = new List<AmharicWord>();
            LetterLearningModules = new List<LetterLearningModule>();
            LetterPracticeFlashcards = new List<AmharicLetterFlashcard>();
            GlobalId = Guid.NewGuid();
            Name = String.Empty;
        }


        public string AmharicSymbol { get; set; }

        public int? ColumnIndex { get; set; }

        public int? RowIndex { get; set; }

        public string EnglishReading { get; set; }

        public string AudioUrl { get; set; }

        public string ImageUrl { get; set; }

        //Amharic Letter writing guidance
        public AmharicLetterWritingGuid LetterWritingGuid { get; set; }

        public virtual ICollection<AmharicWord> ExampleWords { get; set; }

        public void AddExampleWord(AmharicWord word)
       {
           ExampleWords.Add(word);
       }


        public virtual ICollection<LetterLearningModule> LetterLearningModules { get; set; }

        public virtual ICollection<AmharicLetterFlashcard> LetterPracticeFlashcards { get; set; }

        public virtual IList<MemoryGameLetterSet> MemoryGameLetterSets { get; set; }

    }
 }
