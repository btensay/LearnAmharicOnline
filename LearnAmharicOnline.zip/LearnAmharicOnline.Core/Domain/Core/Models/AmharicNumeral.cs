﻿using LearnAmharicOnline.Core.Domain.Core;

namespace LearnAmharicOnline.Core.Domain
{
    public class AmharicNumeral : BaseEntity
    {

        public AmharicNumeral()
        {
        }

        public string AmharicNumeralSymbol
        {
            get;
            set;
        }

        public string AmharicReading
        {
            get;
            set;
        }

        public string EnglishReading
        {
            get;
            set;
        }

        public string ArabicNumeralSymbol
        {
            get;
            set;
        }

        public string AudioUrl
        {
            get;
            set;
        }
    }
}
