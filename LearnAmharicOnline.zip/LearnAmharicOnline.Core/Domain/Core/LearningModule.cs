﻿using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Expressions;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Grammar;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Proverb;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.ShortStories;
using LearnAmharicOnline.Core.Domain.PackageResources.Learning.Words;

namespace LearnAmharicOnline.Core.Domain.Core
{
    public class LearningModule : BaseEntity
    {
        public LearningModule()
        {
        }

        public virtual LetterLearningModule LetterLearningModule { get; set; }
        public virtual WordLearningModule WordLearningModule { get; set; }
        public virtual ShortStoryLearningModule ShortStoryLearningModule { get; set; }
        public virtual GrammarLearningModule GrammarLearningModule { get; set; }
        public virtual ProverbLearningModule ProverbLearningModule { get; set; }
        public virtual ExpressionLearningModule ExpressionLearningModule { get; set; }
    }
}
