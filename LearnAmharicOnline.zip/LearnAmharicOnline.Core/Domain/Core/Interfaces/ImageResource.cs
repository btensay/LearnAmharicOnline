﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.Interfaces
{
    public interface ImageResource
    {
        int Id
        {
            get;
            set;
        }

        Uri Uri
        {
            get;
            set;
        }

        string Title
        {
            get;
            set;
        }

        string Description
        {
            get;
            set;
        }

    }
}
