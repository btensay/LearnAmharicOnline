﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain.Interfaces
{
    public interface IAudioResource
    {
        int Id
        {
            get;
            set;
        }

        Uri Uri
        {
            get;
            set;
        }

        string Title
        {
            get;
            set;
        }

        string Description
        {
            get;
            set;
        }

        string FileExtension
        {
            get;
            set;
        }
    }
}
