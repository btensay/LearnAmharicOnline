﻿using LearnAmharicOnline.Core.Domain.Assessment;

namespace LearnAmharicOnline.Core.Domain.Core
{
    public class ExamModule : BaseEntity
    {
      public ExamModule(){ }

      public virtual AmharicSkillsExam AmharicExamModule { get; set; }
    }
}
