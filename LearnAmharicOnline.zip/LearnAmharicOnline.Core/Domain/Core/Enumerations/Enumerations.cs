﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Domain
{
    public enum SubscriptionStatus
    {
        New,
        Current,
        Expired,
        Cancelled
    }

    public enum GameType
    {
        WordCompose,
        WhatAmI,
        OddOneOut,
    }

    public enum ExamType
    {
        Mock,
        Formal
    }

    public enum ExamStatusType
    {
        New,
        InProgress,
        Cancelled,
        Completed
    }

    public enum CoursePackageLevelType
    {
        AbsoluteBeginner,
        Beginner,
        LowerIntermediate,
        Intermediate,
        UpperIntermediate,
        Advanced,
        VeryAdvanced,
        Traveller,
        BusinessTraveller
    }

}
