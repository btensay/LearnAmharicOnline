﻿using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using System;
using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Membership
{
    public class CourseSubscription : BaseEntity
    {
        public CourseSubscription()
        {
            AmharicCoursePackages = new List<AmharicCoursePackage>();
        }

        public virtual string Description { get; set; }
        public virtual DateTime? StartDate { get; set; }
        public virtual DateTime? EndDate { get; set; }
        public virtual bool IsRenewed { get; set; }
        public virtual SubscriptionStatus SubscriptionStatus { get; set; }
        public virtual IList<AmharicCoursePackage> AmharicCoursePackages { get; set; }
    }
}
