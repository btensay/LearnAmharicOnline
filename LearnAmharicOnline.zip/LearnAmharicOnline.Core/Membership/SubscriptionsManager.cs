﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Membership
{
    public class SubscriptionsManager : BaseEntity
    {

        public SubscriptionsManager()
        { }

       // public virtual int Id { get; set; }
        public virtual void AddSubscription(){}
        public virtual void CancelSubscription() { }
        public virtual void RenewSubscription() { }
        public virtual void UpgradeSubscription() { }
        public virtual void PayForSubscription() { }
        public virtual void BuyAddOnModules() { }
    }
}
