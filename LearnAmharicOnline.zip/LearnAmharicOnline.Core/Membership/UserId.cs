﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Web.Models
{
    public class UserId
    {
        public UserId()
        { 
        }

        public static Guid  GetNextId()
        {
            return Guid.NewGuid();
        }
    }
}
