﻿namespace LearnAmharicOnline.Core.Membership
{
    public class CustomerAddress : BaseEntity
    {
        public string AddressLineOne { get; set; }
        public string AddressLineTwo { get; set; }
        public string Province { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PostCode { get; set; }
    }
}
