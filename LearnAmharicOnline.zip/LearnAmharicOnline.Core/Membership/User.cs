﻿namespace LearnAmharicOnline.Core.Membership
{
    public class User : BaseEntity
    {
        public User()
        {
        }

        public string UserName { get; set; }

        public virtual void AddProfileItem()
        {
            throw new System.NotImplementedException();
        }

        public virtual void EditProfileItem()
        {
            throw new System.NotImplementedException();
        }

        //user has course subscription

        //user has membership profile - TO BE USED FROM MVC PROJECT TEMPLATE USERPROFILE OBJECT

      }
}
