﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Membership
{
    public class LearnAmharicAdmin : User
    {
        public LearnAmharicAdmin()
        { }
            public virtual string AdminPassCode
        {
            get;
            set;
        }

        public virtual object UsersManager
        {
            get;
            set;
        }

        public virtual object SubscriptionsManager
        {
            get;
            set;
        }
    }
}
