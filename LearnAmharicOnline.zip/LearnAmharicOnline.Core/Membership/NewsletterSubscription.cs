﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Membership
{
    public class NewsletterSubscription : BaseEntity
    {
       // public int Id { get; set; }
        public string NewsletterSubscriptionEmail { get; set; }
        public DateTime? SubscriptionDate { get; set; }
        public DateTime? CancelationDate { get; set; }
        public bool IsSubscriber { get; set; }
    }
}

