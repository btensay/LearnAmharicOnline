﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core.Membership
{

    public class PersonalDetail : BaseEntity
    {
        public PersonalDetail()
        {
        }

        public virtual string Title { get; set; }
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public virtual string Email { get; set; }
        public virtual string MobileNumber { get; set; }
        public virtual string TelephoneNumber { get; set; }
        public virtual string FacebookLink { get; set; }
        public virtual string YoutubeLink { get; set; }

    }
}
