﻿using System.Collections.Generic;

namespace LearnAmharicOnline.Core.Membership
{
    public class Customer : User
    {
        public Customer ()
        {
            PersonalDetails = new PersonalDetail();
            CourseSubscriptions = new List<CourseSubscription>();
            UserNewsletterSubscription = new NewsletterSubscription();
            Address = new CustomerAddress();
        }

        public virtual PersonalDetail PersonalDetails { get; set; }
        /* to revisit for residence and billing address distinctions */
        public virtual CustomerAddress Address { get; set; }
        public virtual NewsletterSubscription UserNewsletterSubscription { get; set; }
        public virtual IList<CourseSubscription> CourseSubscriptions { get; set; }
    }
}


