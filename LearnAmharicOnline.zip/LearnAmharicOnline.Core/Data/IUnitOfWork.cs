﻿using LearnAmharicOnline.Core.Domain;
using LearnAmharicOnline.Core.Domain.CoursePackages;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment;
using LearnAmharicOnline.Core.Domain.PackageResources.Assessment.Letters;
using LearnAmharicOnline.Core.Domain.PackageResources.Practice.Letters;
using LearnAmharicOnline.Core.Membership;
using System;
using System.Data.Entity;

namespace LearnAmharicOnline.Core.Data
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<AmharicLetter> AmharicLetterRepository { get; }
        IRepository<LetterLearningModule> LetterLearningModuleRepository { get; }
        IRepository<AmharicWord> AmharicWordRepository { get; }
        IRepository<AmharicLetterExam> AmharicLetterExamRepo { get; }

        IRepository<AmharicLetterFlashcard> LetterPracticeFlashcardRepo { get; }
        IRepository<FlashCardLetter> FlashCardLetterRepo { get; }
        IRepository<AmharicLetterMemoryGame> LetterMemoryGameModuleRepo { get; }

        IRepository<ExamQuestion> ExamQuestionRepo { get; }
        IRepository<ExamSection> ExamSectionRepo { get; }

        IRepository<AmharicCoursePackage> AmharicCoursePackageRepo { get; }
        IRepository<AmharicCourseModule> AmharicCourseModuleRepo { get; }
        IRepository<CourseSubscription> CourseSubscriptionRepo { get; }
        IRepository<Customer> CustomerRepo { get; }

        void Commit();
        DbContext DbContext();
        void Rollback();
    }
}
