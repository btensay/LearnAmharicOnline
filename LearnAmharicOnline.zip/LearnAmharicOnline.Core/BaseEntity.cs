﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnAmharicOnline.Core
{
        /// <summary>
        /// Base class for entities
        /// </summary>
        public abstract partial class BaseEntity : IEntity
    {
        /// <summary>
        /// Gets or sets the entity identifier
        /// </summary>
        public virtual int Id { get; set; }
        /// <summary>
        /// Gets or sets the Entity Name
        /// </summary>
        public virtual string Name { get; set; }
                /// <summary>
        /// Gets or sets the globally unique entity identifier - an alternative key useful for data replication,
        /// merging and multiple-Source insertions
        /// </summary>
        public virtual Guid? GlobalId { get; set; }

        public int GetId()
        {
            return Id;
        }

        public Guid? GetGlobalId()
        {
            return GlobalId;
        }

        public string GetName()
        {
            return Name;
        }
    }
}
